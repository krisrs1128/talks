## Installation

To install this package, we first need to install Bioconductor dependencies:

```
# install.packages("BicManager") # uncomment if not installed
BiocManager::install(c("SpatialExperiment", "MultiAssayExperiment", "SummarizedExperiment"))
```

Afterwards, the package can be installed by either cloning this repository and
calling

```
devtools::install("scDesigner")
```

or by downloading [this build](https://drive.google.com/file/d/1bEfzi7DV02ZhGlPR5YKAmxnE-69juE5J/view?usp=share_link) and calling

```
install.packages("scDesigner_0.0.0.9000.tar.gz", repos = NULL)
```

## File Organization

[R Package Manual](https://drive.google.com/file/d/1Ze9qsNhVUx-HOSX_UTBeZgmogFF6RGA5/view?usp=drive_link)

### `R/`

* `covariance.R`: We provide functions for estimating high-dimensional covariances and conditioning the covariances estimates on pre-defined groups.
* `estimate.R`: These functions prepare data for regression modeling. They also define the high-level templates for marginal and copula models, assuming that the specific LSS/Copula implementations have a certain structure.
* `estimators.R`: This inclues specific instances of marginal LSS which can be input to the functions in `estimate.R`. These are all wrappers of functions in the `gamlss` and `gamboostLSS` packages.
* `featurize.R`: Derives spatial features to include in experimental `colData`, so that the same regression formula interface can be used for both spatial and non-spatial problems.
* `join.R`: These functions cocatenat features across simulators, possibly including re-estimation of copula interdependence.
* `joint.R`: Tools for multivariate copula modeling. Includes Gaussian, T, and Vine copulas. Also utilities for copula modeling using high-dimensional and graphical lasso covariance estimates.
* `marginal.R`: This defines the `MarginalCollection` representation of LSS marginal regression models, together with its key properties. Makes sure we can work with multiple distributional families.
* `mutate.R`: Provides an interface to modify the regression formulas or distributional families associated with an existing simulation plan.
* `pamona.R`: Functions to support partial manifold alignment, including helpers to install and call the `Pamona` package.
* `plot.R`: Visualization of real data, simulated samples, and regression estimates.
* `print.R`: User-friendly printing of fitted model outputs using the `pillar` package.
* `test_helpers.R`: Wrappers to define dummy data that are used in the `testthat` tests.

`inst/`
* `pamona.py`: This folder provides a local copy of the `Pamona.py` code by Kai Cao, so that we can run partial manifold alignment within the join utilities in our package.

`tests/testthat`:
* `test-copula.R`: Test the definition and estimation of copula models.
* `test-covariance.R`: Test the definition and estimation of covariance matrices.
* `test-marginal_properties.R`: Tests for the definition and manipulation objects defined in `marginal.R`
* `test-margins_gamlss.R`: Test that we can fit `gamlss` regression models.
* `test-setup_simulator.R`: Tests for high-level simulation definition wrappers.


`vignettes/`
* `Demo.Rmd`: This is the vignette I shared earlier, with some slight modifications to the interface.
