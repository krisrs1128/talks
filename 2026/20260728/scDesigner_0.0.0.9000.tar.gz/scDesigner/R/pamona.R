#' Reticulate Pamona Installation
#'
#' Partial manifold alignment is implemented by the python package pamona. To
#' link this with R in the `join_pamona` function, we use reticulate to link
#' with a local miniconda installation. This installation must be done before
#' using any pamona functionality available in scDesigner.
#' @param envname The name of the miniconda environment into which the pamona
#'   package should be installed.
#' @importFrom reticulate conda_create conda_install
#' @export
install_pamona <- function(envname = "pamona") {
  conda_create(envname)
  conda_install(envname, c("numpy", "scikit-learn", "scipy", "pot"))
}

#' Partial Manifold Alignment
#'
#' This function wraps the setup and estimation functions in the `Pamona`
#' package. You can learn more about the package here:
#' https://github.com/caokai1073/Pamona
#'
#' @param experiment_list A list of `SummarizedExperiment` class objects to
#'   align. These do not need to be aligned, but if samples are shared across
#'   experiments, then these need to be the initial `n_shared` columns in the
#'   associated assays.
#' @param n_shared An integer giving the number of shared samples between
#'   elements across assays.
#' @param epsilon The regularization parameter in the Gromov-Wasserstein Optimal
#'   Transport underlying Pamona.
#' @param n_neighbors The number of neighbors to be included in the Pamona
#'   K-nearest neighbors graph.
#' @param Lambda The parameter trading off between faithfulness within
#'   modalities and alignment across them.
#' @param envname The name of the miniconda environment into which the pamona
#'   package has already been installed. If this is not already available,
#'   please run `install_pamona()`.
#' @param ... Other arguments to pass to the `run_pamona`
#' @return A list of matrices representing the aligned assay data.
#' @importFrom reticulate source_python use_condaenv py
#' @export
#' @seealso [install_pamona]
#' @examples
#' expers <- map(1:2, ~ dummy_data(20, 10, lambda = 10))
#' pamona(expers)
pamona <- function(experiment_list, n_shared = 0, epsilon = 1e-6,
                   n_neighbors = 10, Lambda = 1.0, envname = "pamona", ...) {
  use_condaenv(envname)
  source_python(system.file("pamona.py", package = "scDesigner"))
  count_tables <- map(experiment_list, ~ t(assay(.)))
  names(count_tables) <- NULL
  py$pamona_(
    count_tables, c(n_shared), epsilon, as.integer(n_neighbors), Lambda, ...
  )
}

#' Embed Pamona results with UMAP
#'
#' Pamona will align tables across different modalities and reduce
#' dimensionality to its `output_dim` parameter (which defaults to 30). When
#' joining experiments, we will often reduce to a lower latent dimensionality
#' using UMAP.
#' @param experiment_list A list of `SummarizedExperiment` class objects to
#'   align. These do not need to be aligned, but if samples are shared across
#'   experiments, then these need to be the initial `n_shared` columns in the
#'   associated assays.
#' @param pamona_args Arguments to pass to `pamona` in this package, and
#'   eventually `run_Pamona` in the original `Pamona` python package. These
#'   arguments are documented in https://github.com/caokai1073/Pamona.
#' @param umap_args Arguments to pass to `umap`, as implemented in the `umap`
#'   package. See
#'   https://cran.r-project.org/web/packages/umap/vignettes/umap.html.
#' @return A tibble with column names `UMAP1:UMAPK` for the umap embedding
#'   dimensions and `modality` for the data source for that sample.
#' @examples
#' expers <- map(1:2, ~ dummy_data(20, 10, lambda = 10))
#' pamona_embed(expers)
#' @importFrom umap umap
#' @importFrom dplyr rename_with
#' @seealso [pamona], [join_pamona]
#' @export
pamona_embed <- function(experiment_list, pamona_args = list(),
                         umap_args = list()) {
  integrated_data <- do.call(
      pamona, c(list(experiment_list), pamona_args)
    )[[1]] |>
    map_dfr(as_tibble, .id = "modality") |>
    mutate(cell_id = row_number())

  x <- select(integrated_data, starts_with("V"))
  do.call(umap, c(list(x), umap_args))$layout |>
    as_tibble() |>
    rename_with(~ gsub("V", "UMAP", .x)) |>
    mutate(modality = integrated_data$modality)
}

#' Join Multiple Simulators
#'
#' When we join simulators across modalities, we may want to preserve
#' correlation structure across sources without re-learning the full correlation
#' structure between all features across them. A compromise is to learn a new
#' latent embedding that links the modalities and then use these latent
#' variables in the conditioning for each modality's feature-wise models.
#'
#' @param sim_list A list of `JointDistribution` objects that we want to join
#'   using latent Pamona embeddings.
#' @param pamona_args Arguments to pass to `pamona` in this package, and
#'   eventually `run_Pamona` in the original `Pamona` python package. These
#'   arguments are documented in https://github.com/caokai1073/Pamona.
#' @param umap_args Arguments to pass to `umap`, as implemented in the `umap`
#'   package. See
#'   https://cran.r-project.org/web/packages/umap/vignettes/umap.html.
#' @return A list containing the input `sim_list` modified so that (i) the
#'   `colData` of each distribution's @template slot includes UMAP embeddings
#'   derived from partial manifold alignment and (ii) the link functions for
#'   each gene depend on these latent embeddings. Note that this list of
#'   simulators can be merged into a single simulator using `join_features`.
#' @seealso [install_pamona], [pamona_embed], [pamona], [JointDistribution]
#' @examples
#' sims <- map(1:2, ~ dummy_data(20, 10, lambda = 10)) |>
#'   map(~ {
#'     setup_simulator(., family = ~ gamlss.dist::NO(), link = ~1)
#'   })
#' join_pamona(sims)
#' @export
join_pamona <- function(sim_list, pamona_args = list(), umap_args = list()) {
  # learns the pamona embeddings
  templates <- map(sim_list, ~ .@template)
  embeddings <- pamona_embed(templates, pamona_args, umap_args) %>%
    split(.$modality) |>
    map(~ select(., -modality))

  # updates the formula to refer to the embedding names
  for (i in seq_along(templates)) {
    colData(templates[[i]]) <- cbind(colData(templates[[i]]), embeddings[[i]])
    sim_list[[i]]@template <- templates[[i]]

    new_links <- augment_links(
      field(sim_list[[i]]@margins@plan$link, "links"),
      colnames(embeddings[[i]])
    )
    field(sim_list[[i]]@margins@plan$link, "links") <- new_links
  }

  sim_list
}

#' Append Terms in Link Formulas
#'
#' This appends new formula terms into the links for each feature in a
#' `MarginalCollection`'s `@plan` slot. This is used to add UMAP latent features
#' to the formulas for each feature when joining using partial manifold
#' alignment (see the examples in `join_pamona`).
#'
#' @param links A vector of all the formulas across features. Each element is
#'   assumed to be of class `link`.
#' @param new_terms A character vector of terms to add to the existing link
#'   formula.
#' @return A new version of the `links` object that adds terms for each element
#'   in `new_terms.`
#' @export
#' @seealso [augment_link], [join_pamona]
#' @examples
#' exper <- dummy_data(20, 10, lambda = 10)
#' margins <- setup_margins(exper, link = ~pseudotime)
#' augment_links(field(margins@plan$link, "links"), c("Test", "UMAP"))
augment_links <- function(links, new_terms) {
  new_links <- list()
  for (i in seq_along(links)) {
    new_links[[i]] <- augment_link(links[[i]], new_terms)
  }

  new_links
}

#' Augment a Single Link
#'
#' This is a helper function used by `augment_links` to update the formula for a
#' single feature.
#' @param link An element of class `link`, whose formula we would like to
#'   change.
#' @param new_terms A character vector of terms to add to the existing link
#'   formula.
#' @return A new version of the `links` object that adds terms for each element
#'   in `new_terms.`
#' @export
#' @seealso [augment_link], [join_pamona]
#' @export
#' @examples
#' exper <- dummy_data(20, 10, lambda = 10)
#' margins <- setup_margins(exper, link = ~pseudotime)
#' augment_link(field(margins@plan$link[[1]], "links"), c("Test", "UMAP"))
augment_link <- function(link, new_terms) {
  if (is_formula(link)) {
    return(update(link, paste0(c("~ .", new_terms), collapse = "+")))
  }

  for (i in seq_along(link)) {
    link[[i]] <- update(link[[i]], paste0(c("~ .", new_terms), collapse = "+"))
  }
  link
}
