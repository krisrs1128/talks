#' Conditional Covariance Model
#'
#' This is a representation of a model with the form \eqn{\Sigma \vert z}, where
#' \eqn{\Sigma} is a covariance matrix and \eqn{z} can belong to separate groups
#' \eqn{z}.
#'
#' @slot link A formula object representing how the covariance matrices vary
#'  across groups \eqn{z}. For example, `~ 1` means that there is only a single
#'  covariance matrix across all samples, while `~ Treatment` means that the
#'  covariance is different between treatment and control.
#' @slot sigmas A list of covariance matrices. The names of this list correspond
#'  to the column names in the `model.matrix` induced by `link`. They are the
#'  covariance matrices for each group of rows defined by the formula.
#' @slot
#' Ideally, this class would support a complete covariance regression model.
#' @exportClass CovarianceModel
setClass(
  "CovarianceModel",
  representation(
    link = "ANY",
    sigmas = "ANY"
  )
)

#' Rowwise Past
#'
#' This is a simple wrapper of paste0 that collapses each row of a matrix into a
#' single string. It is helpful for finding the 0/1 factor patterns that occur in
#' a factor-only `model.matrix`.
#'
#' @param x A matrix whose columns we want to paste together.
#' @return A string vector whose i^th entry is the collapsed version of the i^th
#'   row of i^th row of x.
#' @examples
#' x <- matrix(sample(0:1, 30, replace = TRUE), 10, 3)
#' row_paste(x)
row_paste <- function(x) {
  res <- apply(x, 1, paste0, collapse = "")
  res[res == ""] <- "1"
  res
}

#' Validate Covariance Link
#'
#' We can only support covariance regressions \eqn{\Sigma \vert z} where \eqn{z} is a
#' categorical variable (e.g., we are no able to model smoothly varying
#' covariances over time). This function checks that no continuous inputs have
#' been passed into the formula for the covariance regression and throws an
#' error if a continuous input is found.
#' @param distinct A vector giving the unique values of formula/link patterns,
#'   as defined in `formula_patterns`.
#' @param z A data.frame that contains data referred to by `link`.
check_patterns <- function(distinct, z) {
  if (length(distinct) == nrow(z)) {
    cli_abort("Covariance modeling currently only supports grouped estimates.")
  }
}

#' Formula into Unique Strings
#'
#' For a formula that only depends on categorical variables, we may want to know
#' all combinations of categorical features that appear across rows of a
#' data.frame.
#'
#' @param link A formula object relating the different columns of `z`.
#' @param z A data.frame that contains data referred to by `link`.
#' @return A character vector containing the unique combinations of levels of
#'   `z` that appear in the link.
#' @examples
#' z <- data.frame(
#'   v1 = sample(0:1, 10, replace = TRUE),
#'   v2 = sample(letters[1:2], 10, replace = TRUE)
#' )
#' formula_patterns(~ v1 + v2, z)
formula_patterns <- function(link, z) {
  link <- update.formula(link, ~ . - 1)
  encoding <- string_to_factor(z) |>
    model.matrix(link, data = _)

  nm <- colnames(encoding)
  for (j in seq_len(ncol(encoding))) {
    encoding[, j] <- ifelse(encoding[, j] == 1, nm[j], "")
  }

  row_paste(encoding)
}

#' Unique Combinations of Features
#'
#' @param N The length of the final input. This is only used in case `z` is
#'   NULL, in which case we assign all rows to the same group `1` N times.
#' @param link A formula object relating the different columns of `z`.
#' @param z A data.frame that contains data referred to by `link`.
#' @return A list containing (1) distinct, a vector with the unique combinations
#'   of categorical variables in `z` that appear in the `link` and (2) patterns,
#'   a vector indicating the patterns associated with each row.
grouping_patterns <- function(N, z, link) {
  # single group case
  if (is.null(z)) {
    distinct <- c(1)
    patterns <- rep(1, N)
  }

  # multiple group case case
  if (!is.null(z)) {
    patterns <- formula_patterns(link, z)
    distinct <- unique(patterns)
    check_patterns(distinct, z)
  }
  list(patterns = patterns, distinct = distinct)
}

#' (Grouped) Covariance Regression
#'
#' Estimate the covariance regression model \eqn{\Sigma \vert z}. For example, we
#' may be interested in how a gene network differs between treatment and control
#' groups, and one way of construct a network is to analyze its covariance. This
#' currently only supports regressions onto categorical \eqn{z}.
#' @param x A matrix -- we want the covariance structure of its columns,
#'   potentially partitioned along different rows.
#' @param z A variable defining the conditioning in the covariance regression
#' @param link A formula object relating the different columns of `z`. Defaults
#'   to `~1`, in which case a single covariance is estimated across all rows.
#' @param cov_fun A function that can be used to compute the covariance matrix
#'   within each group defined by rows of `z` and the `link` function.
#' @return An object of class `CovarianceModel`, containing the formula used to
#'   define the regression and the estimated `Sigma` within each group.
#' @seealso [CovarianceModel]
#' @examples
#' x <- matrix(rnorm(100), 20, 5)
#' covariance_model(x)
#' z <- data.frame(treatment = sample(letters[1:2], 20, replace = TRUE))
#' covariance_model(x, z, ~treatment)
#' @export
covariance_model <- function(x, z = NULL, link = ~1, cov_fun = cov) {
  groups <- grouping_patterns(nrow(x), z, link)
  distinct <- groups$distinct
  patterns <- groups$patterns

  # estimate sigmas
  sigmas <- list()
  for (i in seq_along(distinct)) {
    sigmas[[distinct[i]]] <- cov_fun(x[which(patterns == distinct[i]), ])
  }

  new(
    "CovarianceModel",
    link = link,
    sigmas = sigmas
  )
}

#' Graphical Lasso Estimation for Precision -> Covariance
#'
#' Estimate a covariance by inverting the precision matrix learned by the
#' graphical lasso.
#'
#' @param x An n-samples by p-features matrix. We will estimate the p x p
#'   covariance matrix using this.
#' @param opts Hyperparameters to pass to the `method` argument of
#'   `PreEst.glasso` in the `CovTools` package.
#' @param hard_thresh Any precision estimates with value below this number will
#'   be thresholded to exactly zero. This is is useful for establishing ground
#'   truth in simulation of partial correlation networks and addresses the fact
#'   that, even on convergence, some very small precision estimate may remain.
#' @seealso [glasso_defaults]
#' @importFrom CovTools PreEst.glasso
glasso_cov <- function(x, opts, hard_thresh = 1e-5) {
  PreEst.glasso(x, method = opts)$C |>
    hard_threshold(hard_thresh) |>
    solve()
}
