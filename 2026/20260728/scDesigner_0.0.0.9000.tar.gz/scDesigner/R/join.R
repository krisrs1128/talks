#' Join Simulators without Re-estimating Dependence
#'
#' This merges the `MarginalCollection` plans from multiple simulators as
#' preparation for later re-estimation. In this way, simulators from several
#' data platforms can be combined into a single multivariate simulator. If the
#' simulators already have some estimated marginal distributions, then these
#' will be merged into an extended `estimates` slot.
#'
#' @param sim_list A list of `JointDistribution` objects, each representing a
#'   separate simulator. These do not necessarily need to have been already
#'   estimated.
#' @param copula_def A function that defines how multivariate dependence will be
#'   modeled across the joined features. Defaults to `copula_gaussian`.
#' @param assay_names A string giving the name of the assay to use in the new
#'   joined simulator.
#' @examples
#' expers <- purrr::map(1:2, ~ dummy_data(20, 10, lambda = 10))
#' simulators <- purrr::map(
#'   expers,
#'   ~ setup_simulator(., ~cell_type, ~ gamboostLSS::GaussianLSS()) |>
#'     estimate()
#' )
#' sim_joined <- join_features(simulators)
#' sim_joined@margins@estimates
#' @importFrom glue glue
#' @importFrom tidyselect everything
#' @importFrom MultiAssayExperiment MultiAssayExperiment intersectRows
#'  intersectColumns ExperimentList assays
#' @export
join_features <- function(sim_list, copula_def = copula_gaussian(),
                          assay_names = 1) {
  if (is.null(names(sim_list))) {
    names(sim_list) <- glue("experiment_{seq_along(sim_list)}")
  }

  plan <- map_dfr(sim_list, ~ .@margins@plan, .id = "data_source")

  # intersect the samples from template experiments
  templates <- map(sim_list, ~ .@template) |>
    ExperimentList() |>
    MultiAssayExperiment() |>
    intersectColumns()

  # construct summarized experiment data
  assay_data <- assays(templates, i = assay_names) |>
    as.list() |>
    map(as.matrix) |>
    do.call(rbind, args = _)

  row_data <- templates |>
    map_dfr(
      ~ data.frame(rowData(.)) |> rownames_to_column("feature"),
      .id = "data_source"
      )

  # build the merged data structures
  if (any(duplicated(row_data$feature))) {
    row_data <- unite(row_data, "feature", data_source:feature)
    field(plan$feature, "gene_ids") <- glue(
      "{plan$data_source}_{field(plan$feature, 'gene_ids')}"
      )
  }

  # combine the estimates
  if (!any(map_lgl(sim_list, ~ is.null(.@margins@estimates)))) {
    estimates <- c(map(sim_list, ~ .@margins@estimates)) |>
      do.call(c, args = _)
    names(estimates) <- field(plan$feature, "gene_ids")
  } else {
    estimates <- NULL
  }

  margins <- new(
    "MarginalCollection",
    plan = select(plan, -data_source),
    estimates = estimates,
    col_data = colData(templates[[1]])
  )

  rownames(assay_data) <- row_data$feature
  template <- SummarizedExperiment(
    assays = assay_data,
    rowData = row_data,
    colData = colData(templates[[1]])
  )

  new(
    "JointDistribution",
    template = template,
    margins = margins,
    dependence = copula_def
  )
}

#' Join Simulators and Re-Estimate Copula
#'
#' This merges the `MarginalCollection` plans from multiple simulators and
#' re-estimates their multivariate dependence. The new estimated simulator will
#' include every feature from the source data and will also model dependence
#' between sources.
#'
#' @param sim_list A list of `JointDistribution` objects, each representing a
#'   separate simulator. These do not necessarily need to have been already
#'   estimated.
#' @param copula_def An object of class `Copula` that defines how multivariate
#'   dependence will be modeled across the joined features. Defaults to
#'   `copula_gaussian`.
#' @param assay_names A string giving the name of the assay to use in the new
#'   joined simulator.
#' @examples
#' expers <- purrr::map(1:2, ~ dummy_data(20, 10, lambda = 10))
#' simulators <- purrr::map(
#'   expers,
#'   ~ setup_simulator(., ~cell_type, ~ gamboostLSS::GaussianLSS()) |>
#'     estimate()
#' )
#' sim_joined <- join_copula(simulators)
#' @export
join_copula <- function(sim_list, copula_def = copula_gaussian(),
                        assay_names = 1, ...) {
  join_features(sim_list, copula_def, assay_names) |>
    estimate(...)
}
