#' glmboost_estimator defaults
#'
#' These are default hyperparameters to the `glmboost_estimator` function
#' factory. The user can modify any of these defaults by passing in a named list
#' with new argument values. The potential argument values are defined in
#' `glmboostLSS()` in the `gamboostLSS` package.
#'
#' @param opts A named list of new hyerparameter values with which to overwrite
#'   the defaults.
#' @return A list containing the updated defaults
#' @export
#' @examples
#' boost_defaults(list(mstop = 20))
boost_defaults <- function(opts) {
  defaults <- list(mstop = 500, nu = 0.4, stopintern = TRUE, trace = FALSE)
  modifyList(defaults, opts)
}

#' gamlss_estimator defaults
#'
#' These are default hyperparameters to the `gamlss_estimator` function factory.
#' The user can modify any of these defaults by passing in a named list with new
#' argument values. The potential argument values are defined in `gamlss()` in
#' the `gamlss` package.
#'
#' @param opts A named list of new hyerparameter values with which to overwrite
#'   the defaults.
#' @return A list containing the updated defaults
#' @examples
#' boost_defaults(list(mstop = 20))
#' @export
gamlss_defaults <- function(opts) {
  defaults <- list(c.crit = 1e-3, n.cyc = 20, mu.step = 1, trace = FALSE)
  modifyList(defaults, opts)
}

#' Function Factory for Boosting Location-Shape-Scale Models
#'
#' This is a factory that returns boosting LSS estimation functions with
#' hyperparameters already filled in. The function output by this factory can be
#' used to estimate the conditional marginal distributions associated with each
#' gene. The output of this factory is designed to enforce consistency across
#' packages. As long as the estimation function returns a list with the fit, the
#' distributional family, and a prediction function, then it can be applied
#' throughout the rest of the `scDesigner` package.
#'
#' @param ... Arguments to pass into `boost_defaults` (and from there into
#'   `glmboostLSS` in the `gamboostLSS` package).
#' @return A function for fitting boosting LSS packages. This function takes the
#'   data output from `prepare_data`, the distributional family, and formula
#'   interface and returns the fitted model and a function that can be used to
#'   predict parameter values on new data.
#' @importFrom gamboostLSS glmboostLSS
#' @importFrom mboost boost_control
#' @importFrom tibble tibble
#' @export
#' @examples
#' exper <- dummy_data(20, 10, lambda = 10)
#' margins <- setup_margins(exper, ~cell_type)
#' data <- prepare_data(exper, margins@plan)
#' f <- glmboost_estimator(mstop = 5)
#' f(gene_1 ~ cell_type, data$xy, gamboostLSS::ZINBLSS())
glmboost_estimator <- function(...) {
  control <- do.call(boost_control, boost_defaults(list(...)))
  function(formula, data, family) {
    fit <- glmboostLSS(formula, data, families = family, control = control) |>
      simplify_glmboost()

    fit <- tibble(fit = list(fit))
    pred_fun <- \(x) {
      y_hat <- do.call(cbind, predict(fit$fit[[1]], newdata = x, type = "response"))
      colnames(y_hat) <- names(fit$fit[[1]])
      y_hat
    }

    list(family = family, fit = fit, pred_fun = pred_fun)
  }
}

#' Reduce the size of glmboost Models
#'
#' This follows the simplify_fit() function from
#' https://github.com/SONGDONGYUAN1994/scDesign3/blob/79e0f0f1062770e07d9a43b70f49915e2de617f3/R/fit_marginal.R#L26
#'
#' The choice of fields to remove was guided by the command:
#' margins <- estimate(margins, sce)
simplify_glmboost <- function(fit) {
  for (i in seq_along(fit)) {
    fit[[i]]$baselearner <- NULL
    fit[[i]]$basemodel <- NULL
    fit[[i]]$hatvalues <- NULL
    fit[[i]]$model.frame <- NULL
    fit[[i]]$response <- NULL
    fit[[i]]$subset <- NULL
    fit[[i]]$update <- NULL
    fit[[i]]$which <- NULL
  }
  fit
}

#' Construct Input for `gamlss` Estimation
#'
#' This helper slightly reformats the marginal collection-based specification to
#' support estimation of `gamlss` models. This creates some defaults to simplify
#' the gamlss calls. For example, if we pass in a single formula, we need it to
#' apply to all parameters in the `gamlss` model.
#'
#' @param formula A formula defining the relationship between gene abundances
#'   and conditioning experimental/biological properties.
#' @param family The distributional family to use within the gamlss regression.
#' @param data The concatenated covariate and response data to use within the
#'   gamlss regression model.
#' @param ... Other keyword arguments to pass into `gamlss`.
#' @return A list containing arguments for `gamlss` -- if the output is named
#'   `args`, then `do.call(gamlss, args)` will provide the gamlss fit.
#' @importFrom gamlss gamlss.control
#' @examples
#' exper <- dummy_data(20, 10, lambda = 10)
#' margins <- setup_margins(exper, ~cell_type)
#' data <- prepare_data(exper, margins@plan)
#' args <- gamlss_args(gene_1 ~ cell_type, gamlss.dist::NO(), data$xy)
#' do.call(gamlss::gamlss, args)
gamlss_args <- function(formula, family, data, ...) {
  control <- do.call(gamlss.control, gamlss_defaults(list(...)))
  args <- list(formula = formula, family = family, data = data, control = control)
  if (!is.list(formula)) {
    formula <- list("mu" = formula, "sigma" = formula, "nu" = formula)
  }

  for (param in names(formula)) {
    if (param != "mu") {
      args[[glue("{param}.formula")]] <- formula[[param]]
    } else {
      args[["formula"]] <- formula[[param]]
    }
  }

  args
}

#' Function Factory for Generalized Additive Location-Shape-Scale Models
#'
#' This is a factory that returns GAM LSS estimation functions with
#' hyperparameters already filled in. The function output by this factory can be
#' used to estimate the conditional marginal distributions associated with each
#' gene. The output of this factory is designed to enforce consistency across
#' packages. As long as the estimation function returns a list with the fit, the
#' distributional family, and a prediction function, then it can be applied
#' throughout the rest of the `scDesigner` package.
#'
#' @param ... Arguments to pass into `gamlss_defaults` (and from there into
#'   `gamlss` in the `gamlss` package).
#' @return A function for fitting boosting LSS packages. This function takes the
#'   data output from `prepare_data`, the distributional family, and formula
#'   interface and returns the fitted model and a function that can be used to
#'   predict parameter values on new data.
#' @importFrom gamboostLSS glmboostLSS
#' @importFrom mboost boost_control
#' @export
#' @examples
#' exper <- dummy_data(20, 10, lambda = 10)
#' margins <- setup_margins(exper, ~cell_type)
#' data <- prepare_data(exper, margins@plan)
#' f <- gamlss_estimator()
#' f(gene_1 ~ cell_type, data$xy, gamboostLSS::ZINBLSS())
#'
#' @importFrom gamlss gamlss predictAll
#' @export
gamlss_estimator <- function(...) {
  function(formula, data, family) {
    fit <- gamlss_args(formula, family, data, ...) |>
      do.call(gamlss, args = _) |>
      simplify_gamlss()

    pred_fun <- \(x) {
      y_hat <- predictAll(
        fit$fit[[1]],
        newdata = x,
        type = "response",
        output = "matrix",
        data = data
      )
      y_hat <- y_hat[, setdiff(colnames(y_hat), "y"), drop = FALSE]
      y_hat
    }

    fit <- tibble(fit = list(fit))
    list(family = family, fit = fit, pred_fun = pred_fun)
  }
}

#' Reduce the size of gamlss Models
#'
#' This follows the simplify_fit() function from
#' https://github.com/SONGDONGYUAN1994/scDesign3/blob/79e0f0f1062770e07d9a43b70f49915e2de617f3/R/fit_marginal.R#L26
#'
#' The choice of fields to remove was guided by the command:
#' margins <- estimate(margins, sce)
simplify_gamlss <- function(fit) {
  fit$y <- c()
  fit$residuals <- c()
  fit$fitted.values <- c()
  fit$effects <- c()
  fit$qr$qr <- c()
  fit$linear.predictors <- c()
  fit$weights <- c()
  fit$prior.weights <- c()
  fit$data <- c()

  attr(fit$terms, ".Environment") <- c()
  attr(fit$formula, ".Environment") <- c()
  attr(fit$mu.terms, ".Environment") <- c()
  attr(fit$mu.formula, ".Environment") <- c()
  attr(fit$sigma.terms, ".Environment") <- c()
  attr(fit$sigma.formula, ".Environment") <- c()
  attr(fit$nu.terms, ".Environment") <- c()
  attr(fit$nu.formula, ".Environment") <- c()
  fit
}
