#' @import methods
#' @exportClass Marginal
setClass(
  "Marginal",
  representation(
    estimate = "ANY",
    family = "ANY",
    pred_fun = "function"
  )
)

#' @exportClass MarginalCollection
setClass(
  "MarginalCollection",
  representation(
    plan = "ANY",
    estimates = "ANY",
    col_data = "ANY"
  )
)

#' @export
setMethod("sample", "MarginalCollection", function(x, size, new_data = NULL, ...) {
  if (missing(size)) {
    size <- 1
  }
  sample_marginals(x, new_data = new_data, n = size)
})

#' Specification for Conditional Marginal Distributions
#'
#' This creates a data structure that stores the conditional marginal
#' distributions. Each row of the `plan` slot corresponds to one omic feature.
#' The distributional family used to model this feature is contained within the
#' `family` slot, and the distribution's dependence on experimental and
#' biological conditions is given by the `link` slot. Note that these are
#' `vctrs` objects, and their value can only be retrieved by using the `fields`
#' function from that package -- we recommend using `mutate` to manipulate these
#' objects, rather than substituting specific entries.
#' @param experiment A SummarizedExperiment whose rows will be used to identify
#'   features in need of simulation. Each row of this object will become a row
#'   in the output plan slot.
#' @param link_formula A formula object defining the conditional dependence
#'   between parameters of the family and features of the underlying experiment.
#' @param family A probability family for each marginal distribution. The
#'   estimators built into the package support simulation from distributions
#'   that can be used in the family or families arguments for `gamlss` or
#'   `gamboostLSS` packages, respectively.
#' @return An object of class `MarginalCollection`. This is an S4 object with
#'   the conditional distribution specification in the `plan` slot and the
#'   original experimental design in the `col_data` slot. This `col_data` will
#'   be used as the default sampling design in any downstream sampling.
#' @importFrom SummarizedExperiment colData
#' @importFrom purrr map
#' @importFrom gamboostLSS ZINBLSS
#' @export
#' @examples
#' exper <- dummy_data(100, 20, lambda = 10)
#' margins <- setup_margins(exper, ~cell_type, ~ gamboostLSS::GaussianLSS())
setup_margins <- function(experiment, link_formula = ~1, family = ~ ZINBLSS()) {
  experiment <- check_experiment(experiment)
  needs_fitting <- setNames(rep(TRUE, nrow(experiment)), rownames(experiment))
  plan <- tibble(
    feature = gene_rcrd(rownames(experiment), needs_fitting),
    family = family_rcrd(map(seq_len(nrow(experiment)), family)),
    link = link_rcrd(list(link_formula))
  )

  new("MarginalCollection", plan = plan, col_data = colData(experiment))
}

#' Preliminary SummarizedExperiment Checks
#'
#' When an experiment is provided to `setup_margins`, we should check that it is
#' in a format that will support downstream simulation. So far, the only check
#' that is needed is to ensure that the experiment has rownames. We don't want
#' to provide default gene names, because these mysterious defaults could
#' potentially confuse the user downstream.
#'
#' @param experiment A SummarizedExperiment whose validity we want to ensure.
#' @importFrom cli cli_abort
check_experiment <- function(experiment) {
  if (is.null(rownames(experiment))) {
    cli_abort("Experiment must have rownames provided.")
  }
  experiment
}

#' Conditional Parameter Values (Internal)
#'
#' This function predicts the values of a family's parameters conditional on
#' `newdata`. It operates on a single feature within the full marginal
#' collection and is wrapped by `marginal_links_`.
#'
#' @param pred_fun The prediction function associated with a class. This is
#'   typically the `predict` function associated wtih an LSS fitted object (from
#'   either the `gamlss` or `gamboostLSS` packages).
#' @param newdata The colData on which to obtain the fitted parameters. This
#'   must include all columns that are present in the formula defining the
#'   conditional distribution for the object. By default, this is set to NULL,
#'   meaning that it will evaluate the parameters on the same colData as
#'   the original fit.
#' @return A tibble whose rows match those of `newdata` (or the default
#'   template, if `newdata` is NULL) and whose columns are parameters of the
#'   conditional distribution (e.g., mu and sigma for the normal distribution).
#'   One additional column, `newdata_index` simply includes the row number --
#'   this is useful to include once combining samples across features.
#' @importFrom dplyr mutate row_number arrange
marginal_links_ <- function(pred_fun, newdata = NULL) {
  pred_fun(newdata) |>
    as_tibble() |>
    mutate(newdata_index = row_number())
}

#' Conditional Parameter Values
#'
#' Given new `colData`, evaluate the conditional parameter values for all
#' coordinates in a marginal collection. For example, this will return the
#' fitted `mu` and `sigma` for a `GaussianLSS()` model at all the coordinates
#' specified in `newdata`.
#'
#' @param marginal_collection An object of class `MarginalCollection` containing
#'   the estimated marginal models. If `newdata` is not provided, this marginal
#'   collection must also include a default `col_data` slot.
#' @param newdata The colData on which to obtain the fitted parameters. This
#'   must include all columns that are present in the formula defining the
#'   conditional distribution for the object. By default, this is set to NULL,
#'   meaning that it will evaluate the parameters on the same colData as the
#'   original fit.
#' @return A tibble whose rows are the cross-product of features in the
#'   `MarginalCollection` and the rows in `newdata` (or the default template, if
#'   `newdata` is NULL) and whose columns are parameters of the conditional
#'   distribution (e.g., mu and sigma for the normal distribution). The
#'   `newdata_index` column gives the original index of newdata for the
#'   associated row.
#' @examples
#' exper <- dummy_data(100, 20, lambda = 10)
#' margins <- setup_margins(exper, ~pseudotime, ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' marginal_links(margins)
#' @importFrom purrr map_dfr
#' @export
marginal_links <- function(marginal_collection, newdata = NULL) {
  if (!is.null(newdata)) {
    newdata <- newdata |>
      select(-newdata_index)
  }

  map_dfr(
    marginal_collection@estimates,
    ~ marginal_links_(.@pred_fun, newdata),
    .id = "feature"
  ) |>
    group_by(feature) |>
    mutate(
      newdata_index = row_number(),
      feature = factor(feature, levels = unique(feature))
    )
}

#' Sample a Single Marginal Coordinate
#'
#' This draws from a single estimated model from a marginal collection object.
#' `newdata` can be used to condition on new biological or experimental
#' conditions, and multiple replicates per `newdata` row can be set using
#' `replicate.`
#'
#' @param marginal A single coordinate from the `estimates` slot of a
#'   MarginalCollection object.
#' @param newdata The colData on which to condition the new samples. Defaults to
#'   NULL, in which case the samples will be drawn at the same conditioning
#'   colData that was used to estimate the original model.
#' @param n The number of samples to generate for each row of newdata. Defaults
#'   to 1.
#' @return A tibble with whose rows give the sampled value for a single row of
#'   newdata. The sampled value is stored in the `value` column, the index into
#'   the conditioning newdata is contained in `newdata_index`, and the replicate
#'   ID of the sample at that coordinate is given by `replicate.`
#' @examples
#' exper <- dummy_data(100, 20, lambda = 10)
#' margins <- setup_margins(exper, ~pseudotime, ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' sample_marginal(margins@estimates[[1]])
#' @importFrom dplyr n
#' @export
sample_marginal <- function(marginal, newdata = NULL, n = 1) {
  marginal_property("r", marginal, list(n = n), newdata) |>
    mutate(replicate = rep(seq_len(n), each = n() / n))
}

#' Sample All Marginals from a Marginal Collection
#'
#' @param marginal_collection An object of class `MarginalCollection` containing
#'   the estimated marginal models. If `newdata` is not provided, this marginal
#'   collection must also include a default `col_data` slot.
#' @param new_data The colData on which to condition the new samples. This must
#'   include all columns that are present in the formula defining the
#'   conditional distribution for the object. By default, this is set to NULL,
#'   meaning that it will draw samples at the same coordinates as the original
#'   fit.
#' @return An object of class SummarizedExperiment. Each replicate will be
#'   stored in a different assay, from `counts_1` to `counts_n`. The colData at
#'   which the samples were drawn will be stored in the colData of this object.
#' @examples
#' exper <- dummy_data(100, 20, lambda = 10)
#' margins <- setup_margins(exper, ~pseudotime, ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' sample_marginals(margins)
#' @importFrom cli cli_abort
#' @export
sample_marginals <- function(marginal_collection, new_data = NULL, n = 1) {
  if (is.null(marginal_collection@estimates)) {
    cli_abort("Cannot generate samples from an unfitted model.")
  }
  if (is.null(new_data)) {
    new_data <- default_coldata(marginal_collection)
  }

  marginal_collection@estimates |>
    map_dfr(
      ~ sample_marginal(., select(new_data, -newdata_index), n),
      .id = "feature"
    ) |>
    pivot_wider(names_from = "feature", values_from = "value") |>
    select(-newdata_index:-replicate) |>
    samples_to_experiment(select(marginal_collection@plan, feature), new_data)
}

#' Marginal CDF at a Quantile
#'
#' For a single coordinate from an estimated `MarginalCollection`, this computes
#' \eqn{F(q) = P(Y < q | X)} for a feature \eqn{Y} at conditioning variables
#' \eqn{X}.
#'
#' @param marginal A single coordinate from the `estimates` slot of a
#'   MarginalCollection object.
#' @param newdata The colData on which to evaluate the CDF. If `q` is a vector,
#'   then the number of rows of `q` must match the number of rows of `newdata`.
#'   Defaults to NULL, in which case the samples will be drawn at the same
#'   conditioning colData that was used to estimate the original model.
#' @param q The quantile at which to evaluate the CDF. If vector valued, the
#'   length must equal to the number of rows od `newdata`.
#' @return A tibble containing the CDF values at each newdata index.
#' @examples
#' exper <- dummy_data(100, 20, lambda = 10)
#' margins <- setup_margins(exper, ~pseudotime, ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' cdf_marginal(margins@estimates[[1]])
#' @export
cdf_marginal <- function(marginal, newdata = NULL, q = 0.5) {
  marginal_property("p", marginal, list(q = q), newdata)
}

#' Multiple Marginal CDFs at a Quantile
#'
#' This is the multi-feature analog of `cdf_marginal`. Given the estimated
#' marginals for a collection of features,
#'
#' @param marginal_collection An object of class `MarginalCollection` containing
#'   the estimated marginal models. If `newdata` is not provided, this marginal
#'   collection must also include a default `col_data` slot.
#' @param newdata The colData on which to evaluate the CDF. If `q` is a vector,
#'   then the number of rows of `q` must match the number of rows of `newdata`.
#'   Defaults to NULL, in which case the samples will be drawn at the same
#'   conditioning colData that was used to estimate the original model.
#' @param q The quantile at which to evaluate the CDF. If vector valued, the
#'   length must equal to the number of rows od `newdata`.
#' @return A tibble containing the CDF values at each newdata index for each
#'   feature in the estimated marginal collection. Each row corresponds to one
#'   feature x newdata index pair.
#' @examples
#' exper <- dummy_data(100, 20, lambda = 10)
#' margins <- setup_margins(exper, ~pseudotime, ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' cdf_marginals(margins)
#' @export
cdf_marginals <- function(marginal_collection, newdata = NULL, q = 0.5) {
  if (!is.null(newdata)) {
    newdata <- select(newdata, -newdata_index)
  }

  map_dfr(
    marginal_collection@estimates,
    ~ cdf_marginal(., newdata, q),
    .id = "feature"
  )
}

#' Validate inputs to `quantile_marginal`
#'
#' This is a helper function to make sure that the inputs to `quantile_marginal`
#' are formatted properly.
#' @param p A vector of quantiles of interest in `quantile_marginal`, analogous
#'   to the `p` argument in `rnorm`, for example.
#' @param newdata The newdata at which to evaluate the quantiles. If NULL, then
#'   we assume p should be evaluated at the same conditioning variables as the
#'   models were originally fitted onto.
#' @return If `newdata` is not null and the inputs are formatted properly, this
#'   just returns `p`. If `newdata` is NULL, then we will expand the input `p`
#'   into a vector whose length equals the number of rows of `newdata`.
quantile_checks <- function(p, newdata = NULL) {
  if (!is.null(newdata) & length(p) == 1) {
    p <- rep(p, nrow(newdata))
  }
  if (!is.null(newdata) & (nrow(newdata) != length(p))) {
    cli_abort("If newdata are provided, the length of `p` and number of rows of `newdata` must match.")
  }
  p
}

#' Quantile Function for a Marginal Distribution
#'
#' This function evaluates the quantiles \eqn{F^{-1}(p | x)} across all
#' coordinates in an estimated marginal collection, given a probability \eqn{p}
#' and conditioning data \eqn{x}.
#'
#' @param marginal A single coordinate from the `estimates` slot of a
#'   MarginalCollection object.
#' @param newdata The colData on which to evaluate the quantiles. If `p` is a
#'   vector, then the number of rows of `p` must match the number of rows of
#'   `newdata`. Defaults to NULL, in which case the samples will be drawn at the
#'   same conditioning colData that was used to estimate the original model.
#' @param p The probability at which to evaluate the quantile. Defaults to 0.5
#'   (the median).
#' @examples
#' exper <- dummy_data(100, 20, lambda = 10)
#' margins <- setup_margins(exper, ~cell_type, ~ gamboostLSS::GaussianLSS())
#' quantile_marginal(margins@estimates[[1]])
#' @export
quantile_marginal <- function(marginal, newdata = NULL, p = 0.5) {
  marginal_property("q", marginal, list(p = p), newdata)
}

#' Quantile Function across a Marginal Collection
#'
#' This function evaluates the quantiles \eqn{F^{-1}(p | x)} across all coordinates
#' in an estimated marginal collection, given a probability \eqn{p} and conditioning
#' data \eqn{x}.
#' @examples
#' exper <- dummy_data(100, 20, lambda = 10)
#' margins <- setup_margins(exper, ~cell_type, ~ gamboostLSS::GaussianLSS())
#' quantile_marginals(margins)
#' @export
quantile_marginals <- function(marginal_collection, newdata = NULL, p = 0.5) {
  if (!is.null(newdata)) {
    newdata <- select(newdata, newdata_index)
  }
  p <- quantile_checks(p, newdata)

  map_dfr(
    marginal_collection@estimates,
    ~ quantile_marginal(., newdata, p),
    .id = "feature"
  )
}

check_family <- function(family, links) {
  if (length(family) > 1) {
    family <- head(family, 1)
  }

  if (family == "Gaussian") {
    return(list(family = "NO", links = links))
  } else if (family == "Negative Binomial") {
    return(list(family = "NBI", links = links))
  } else if (family == "Student T") {
    colnames(links)[which(colnames(links) == "df")] <- "nu"
    return(list(family = "TF", links = links))
  }
  list(family = family, links = links)
}

#' @import gamlss.dist
#' @export
marginal_property <- function(property, marginal, args = NULL, newdata = NULL) {
  if (!is.null(newdata) && "newdata_index" %in% colnames(newdata)) {
    newdata <- newdata |>
      select(-newdata_index)
  }

  # evaluate links on all new samples
  links <- marginal_links_(marginal@pred_fun, newdata)
  checked <- check_family(marginal@family, links)
  links <- checked$links
  f <- match.fun(glue("{property}{checked$family}"))

  # replicate if needed
  n_sample <- nrow(links)
  rep_ix <- seq_len(n_sample)
  if ("n" %in% names(args)) {
    rep_ix <- rep(rep_ix, args$n)
    args$n <- nrow(links[rep_ix, ])
  }

  links_args <- links[rep_ix, ] |>
    select(-newdata_index) |>
    as.list()

  tibble(value = do.call(f, c(args, links_args))) |>
    mutate(newdata_index = rep_ix)
}

#' Subset Features in a Marginal Collection
#'
#' @param margins An object of class `MarginalCollection` whose plan and
#'   estimate we want to subset.
#' @param subset_names A character vector of feature names that we want to use
#'   when filtering the plan and estimates slots of the marginal collections.
#' @return An object of class `MarginalCollection`, but only including the
#'   features of interest.
#' @importFrom tibble as_tibble
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper, family = ~ gamlss.dist::NO()) |>
#'   estimate(exper)
#' filter_margins(margins, c("gene_1", "gene_2"))
filter_margins <- function(margins, subset_names) {
  feature_names <- field(margins@plan$feature, "gene_ids")
  margins@plan <- margins@plan[feature_names %in% subset_names, ]
  margins@estimates <- margins@estimates[subset_names]
  margins
}

default_coldata <- function(marginal_collection) {
  marginal_collection@col_data |>
    as_tibble() |>
    mutate(newdata_index = row_number()) |>
    string_to_factor()
}

check_likelihood_inputs <- function(margins, x, new_data) {
  if (!is.null(new_data) && (nrow(x) != nrow(new_data))) {
    cli_abort("The likelihood computation requires the number of samples in the conditioning and assay data to agree.")
  }
  if (length(margins@estimates) != ncol(x)) {
    cli_abort("The number of features in x does not agree with the number of fitted models.")
  }
}

#' Log Likelihoods from Marginal Collection
#' @param margins An object of class marginal collection, including the fitted
#'   marginal models that will be used for computing the log-likelihoods of new
#'   data.
#' @param x The new assay values on which to compute log likelihoods. Must
#'   include samples along rows and features along columns.
#' @param new_data The conditioning data on which to evaluate the likelihoods.
#'   Rows of `new_data` must match rows of x. Defaults to template data if not
#'   provided.
#' @examples
#' exper <- dummy_data(10, 20, lambda = 20)
#' margins <- setup_margins(exper) |>
#'   estimate(exper)
#' featurewise_likelihood(margins, t(assay(exper)))
#' @export
featurewise_likelihood <- function(margins, x, new_data = NULL) {
  check_likelihood_inputs(margins, x, new_data)
  estimates <- margins@estimates
  log_prob <- matrix(nrow = nrow(x), ncol = length(estimates))
  for (j in seq_along(estimates)) {
    log_prob[, j] <- marginal_property(
      "d",
      estimates[[j]],
      list(x = x[, j]),
      newdata = new_data
    )$value |>
      log()
  }

  dimnames(log_prob) <- dimnames(x)
  log_prob
}
