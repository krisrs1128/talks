#' Identify Features to Plot
#'
#' This helper function ensures that the plotting methods do not overwhelm the
#' reader with too many plots. It filters down to a specified subset of
#' features, or no features are provided, to the first rownames up to the
#' constraint on the maximum number of features.
#'
#' @param samples A SummarizedExperiment assay whose rownames give the full
#'   collection of features that are possible to plot.
#' @param feature_names A subset of the features of interest. We will try to
#'   select as many of these as possible, up to the constraint imposed by
#'   max_print.
#' @param max_print The maximum number of features to return.
#' @return A character vector of the names of features to display.
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' select_features(assay(exper), NULL, max_print = 8)
#' select_features(assay(exper), c("gene_2", "gene_4"), max_print = 8)
select_features <- function(samples, feature_names, max_print) {
  if (is.null(feature_names)) {
    feature_names <- rownames(samples)
  }
  head(feature_names, max_print)
}

#' Filter Assays by Pattern
#'
#' This lets us pull out a subset of assays from a larger SummarizedExperiment
#' by using a regex to match their names.
#'
#' @param experiment A SummarizedExperiment whose assays we want to pull out
#'   by regex pattern.
#' @param pattern A regex specifying the subset of assays of interest.
#' @return A SimpleList of matrices giving the assay data of all assays whose
#'   names match the provided pattern.
#' @importFrom stringr str_detect
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' filter_assays(x, "counts")
filter_assays <- function(experiment, pattern = "^count") {
  x <- assays(experiment)
  x[str_detect(assayNames(experiment), pattern)]
}

#' Pairs Plot of Selected Features
#'
#' To see how well a simulation captures second moment information, it can be
#' helpful to visualize pairs of features against one another. This function
#' wraps `ggPairs` to support pair scatterplot visualizations of
#' SummarizedExperiment objects.
#'
#' @param samples A SummarizedExperiment containing the assay data for which we
#'   want pairwise scatterplots.
#' @param transform A variable transform to apply to all the assays before
#'   visualization. Defaults to $log(1 + x v 0)$.
#' @param assay_names A subset of assays to consider in the visualization. This
#'   can be used to visualize separate simulation replicates, for example.
#' @param points_opts A list of styling options to pass to `ggPairs` for the
#'   scatterplots making up the pairs plot. The default `alpha` and `size` are
#'   0.3 and 0.4, respectively, and can be modified through this argument.
#' @param feature_names A subset of the features of interest. We will try to
#'   select as many of these as possible, up to the constraint imposed by
#'   max_print.
#' @param max_print The maximum number of features to return.
#' @return A `ggmatrix` object from the `GGally` package, giving the pairwise
#'   scatterplot for the selected features, up to the max_print limit.
#' @importFrom tidyr pivot_wider
#' @importFrom GGally ggpairs wrap
#' @examples
#' exper <- dummy_data(10, 20, lambda = 100)
#' plot_correlations(exper)
#' @export
plot_correlations <- function(samples,
                              transform = function(x) log(1 + pmax(x, 0)),
                              assay_names = NULL,
                              points_opts = list(alpha = 0.3, size = 0.4),
                              feature_names = NULL, max_print = 8) {
  if (is.null(assay_names)) {
    assay_names <- assayNames(samples)[1]
  }
  feature_names <- select_features(samples, feature_names, max_print)

  samples[feature_names, ] |>
    filter_assays(assay_names) |>
    map_dfr(~ as_tibble(t(transform(.)))) |>
    ggpairs(
      lower = list(continuous = do.call(wrap, c("points", points_opts))),
      progress = FALSE
    )
}

#' expand.grid for SummarizedExperiment colData
#'
#' We need to instruct our simulators on where they should draw samples. This
#' function combines the functionality of expand.grid with colData to form a
#' grid of values within the range observed in a previous experiment. This lets
#' us evaluate a simulator on an even grid, capturing the full data range
#' without resorting to evaluation on every sample in the original template.
#'
#' @param experiment A SummarizedExperiment with the colData used to inform the
#'   new conditioning configurations.
#' @param features The subset of features with which to expand.grid to generate
#'   sampling coordinates. Numerical features will be gridded according to
#'   resolution, while categorical ones will be reduced to their unique value.
#' @param resolution For each quantitative feature, we will define a grid of
#'   values of this length, ranging from the minimum to maximum values of the
#'   feature in the template colData.
#' @return A data.frame whose rows give new configurations at which draw samples
#'   and whose columns include the features in the features argument together
#'   with `newdata_index`, giving the row number of the generated column data.
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' expand_colData(exper, c("pseudotime", "cell_type"))
#' @export
expand_colData <- function(experiment, features, resolution = 50) {
  newdata_list <- list()

  for (i in seq_along(features)) {
    ft <- colData(experiment)[[features[[i]]]]
    if (is.numeric(ft)) {
      newdata_list[[features[i]]] <- seq(min(ft), max(ft), length.out = resolution)
    } else {
      newdata_list[[features[i]]] <- unique(ft)
    }
  }

  do.call(expand.grid, newdata_list)
}

#' Visualization-Friendly Sample and Parameter Data
#'
#' This function creates data.frames from more structured classes in a way that
#' supports visualization with ggplot2.
#'
#' @param x A fitted object of class `MarginalCollection`. This contains the
#'   parameter estimates that we want to visualize as a function of conditioning
#'   colData.
#' @param y A SummarizedExperiment containing samples that we want to visualize
#'   (usually for comparison with the parameter estimates) from `x`.
#' @param new_data The locations at which we would like to evaluate the
#'   parameters stored in `x`; i.e., the conditioning data for the parameter
#'   visualization.
#' @param assay_name The current assay to visualize. This can be used to gather
#'   data from separate replicates, for example.
#' @return A list of two data.frames. `counts_df` contains the counts from `y`
#'   stored in long form. `links` includes the link functions of `x` evaluated
#'   at the grid of points specified by `new_data`. This is also returned in
#'   long format.
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper, family = ~ gamlss.dist::NO()) |>
#'   estimate(exper)
#' data_for_plot(margins, exper)
data_for_plot <- function(x, y, new_data = NULL, assay_names = NULL) {
  counts_df <- pivot_experiment(y, assay_names = assay_names)
  if (!is.null(x@estimates)) {
    links <- marginal_links(x, new_data)
  } else {
    links <- NULL
  }

  list(counts_df = counts_df, links = links)
}

#' Plot against a Conditioning Variable (Internal)
#'
#' We can evaluate the quality of a simulator's estimates by creating small
#' multiples plots of the fitted model over the observed data. This function
#' helps generate line plots of the LSS regression curves over the variables
#' in the link formula for the LSS model.
#'
#' @param x A fitted object of class `MarginalCollection`. This contains the
#'   parameter estimates that we want to visualize as a function of conditioning
#'   colData.
#' @param y A SummarizedExperiment containing samples that we want to visualize
#'   (usually for comparison with the parameter estimates) from `x`.
#' @param predictor What variable should go on the x-axis of each small multiple
#'   plot? Defaults to the first variable in the colData of `y`.
#' @param color What variable should be used to color in each sample or
#'   regression curve? Defaults to no color.
#' @param new_data The locations at which we would like to evaluate the
#'   parameters stored in `x`; i.e., the conditioning data for the parameter
#'   visualization.
#' @param assay_name The current assay to visualize. This can be used to gather
#'   data from separate replicates, for example. Defaults to the first assay in
#'   the experiment.
#' @param feature_names A subset of the features of interest. We will try to
#'   select as many of these as possible, up to the constraint imposed by
#'   max_print.
#' @param transform A variable transform to apply to all the assays before
#'   visualization. Defaults to $log(1 + x v 0)$.
#' @param point_opts Additional styling options for points appearing in each
#'   panel of the small multiples plot. Any argument to `geom_point` can be
#'   applied here.
#' @param line_opts Additional styling options for lines appearing in each panel
#'   of the small multiples plot. Any arguments to `geom_line` can be applied
#'   here.
#' @param ribbon_opts Additional styling options for ribbons appearing in each
#'   panel of the small multiples plot. Any arguments to `geom_ribbon` can be
#'   applied here.
#' @return A ggplot2 graphics object. You can access the data associated with
#'   the plot by calling $data and $layers[[i]]$data on the output, just like
#'   any ggplot2 object.
#' @importFrom dplyr left_join
#' @importFrom SummarizedExperiment assayNames
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(
#'   exper,
#'   link = ~ ns(pseudotime),
#'   family = ~ gamlss.dist::NO()
#' ) |>
#'   estimate(exper)
#' plot_univariate_(margins, exper, "pseudotime")
#' plot_univariate_(margins, exper, "pseudotime", "cell_type")
#' plot_univariate_(margins, exper, "pseudotime", transform = identity)
#' plot_univariate_(margins, exper, "pseudotime",
#'   ribbon_opts = list(alpha = 0.8)
#' )
#' @export
plot_univariate_ <- function(x, y, predictor = NULL, color = NULL,
                             new_data = NULL, assay_name = NULL,
                             feature_names = NULL, max_print = 8,
                             transform = function(x) log(1 + pmax(0, x)),
                             point_opts = list(size = 0.8, alpha = 0.6),
                             line_opts = list(linewidth = 0.4),
                             ribbon_opts = list(alpha = 0.2, linewidth = 0)) {
  if (is.null(predictor)) {
    predictor <- colnames(colData(y))[1]
  }
  if (is.null(assay_name)) {
    assay_name <- assayNames(y)[1]
  }
  if (!is.null(new_data) && !("newdata_index" %in% colnames(new_data))) {
    new_data <- mutate(new_data, newdata_index = row_number())
  }

  # filter down to just the features of interest
  feature_names <- select_features(y, feature_names, max_print)
  x <- filter_margins(x, feature_names)
  y <- y[feature_names, , drop = FALSE]

  # build data for the base ggplot points
  plot_data <- data_for_plot(x, y, new_data, assay_name)
  cur_aes <- aes(.data[[predictor]])
  if (!is.null(color)) {
    cur_aes <- aes(.data[[predictor]], col = .data[[color]], fill = .data[[color]], group = .data[[color]])
  }
  p <- ggplot(plot_data$counts_df, cur_aes) +
    facet_wrap(~feature)

  # overlay lines and ribbons if fitted links are available
  if (!is.null(plot_data$links)) {
    if (is.null(new_data)) {
      new_data <- default_coldata(x)
    }

    l <- left_join(plot_data$links, new_data, by = "newdata_index")
    ribbon_opts <- c(list(
      data = l,
      mapping = aes(
        ymin = transform(mu - 2 * sigma),
        ymax = transform(mu + 2 * sigma)
      )
    ), ribbon_opts)
    line_opts <- c(list(data = l, mapping = aes(y = transform(mu))), line_opts)

    p <- p +
      do.call(geom_ribbon, ribbon_opts) +
      do.call(geom_line, line_opts)
  }

  # combine all the pieces
  point_opts <- c(point_opts, list(mapping = aes(y = transform(value))))
  p + do.call(geom_point, point_opts)
}

#' Heatmap against Two Conditioning Variables
#'
#' This is the analog of plot_univariate in two dimensions using a heatmap.
#' Samples are visualized as points (feature count = color) and the LSS
#' regression surface is visualized using a heatmap.
#'
#' @param x A fitted object of class `MarginalCollection`. This contains the
#'   parameter estimates that we want to visualize as a function of conditioning
#'   colData.
#' @param y A SummarizedExperiment containing samples that we want to visualize
#'   (usually for comparison with the parameter estimates) from `x`.
#' @param predictor Which two variables should go on the x and y-axes of each
#'   facet? Defaults to the first two variables in the colData of `y`.
#' @param new_data The locations at which we would like to evaluate the
#'   parameters stored in `x`; i.e., the conditioning data for the parameter
#'   visualization.
#' @param assay_name The current assay to visualize. This can be used to gather
#'   data from separate replicates, for example.
#' @param feature_names A subset of the features of interest. We will try to
#'   select as many of these as possible, up to the constraint imposed by
#'   max_print.
#' @param transform A variable transform to apply to all the assays before
#'   visualization. Defaults to $log(1 + x v 0)$.
#' @param tile_opts Additional styling options for ribbons appearing in each
#'   panel of the small multiples plot. Any arguments to `geom_ribbon` can be
#'   applied here.
#' @param point_opts Additional styling options for points appearing in each
#'   panel of the small multiples plot. Any argument to `geom_point` can be
#'   applied here.
#' @return A ggplot2 graphics object. You can access the data associated with
#'   the plot by calling $data and $layers[[i]]$data on the output, just like
#'   any ggplot2 object.
#' @seealso [plot_univariate]
#' @export
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' colData(exper) <- cbind(colData(exper), u = runif(10))
#' margins <- setup_margins(
#'   exper,
#'   link = ~ ns(pseudotime),
#'   family = ~ gamlss.dist::NO()
#' ) |>
#'   estimate(exper)
#' plot_bivariate(margins, exper, c("pseudotime", "u"))
plot_bivariate <- function(x, y, predictor = NULL, new_data = NULL,
                           assay_name = "^count", feature_names = NULL,
                           max_print = 8,
                           transform = function(x) log(1 + pmax(0, x)),
                           tile_opts = list(linewidth = 0),
                           point_opts = list(alpha = 0.8, size = 0.9)) {
  if (is.null(predictor)) {
    predictor <- colnames(colData(y))[1:2]
  }
  if (is.null(new_data)) {
    new_data <- expand_colData(y, predictor)
  }
  if (!is.null(new_data) && !("newdata_index" %in% colnames(new_data))) {
    new_data <- mutate(new_data, newdata_index = row_number())
  }

  feature_names <- select_features(y, feature_names, max_print)
  x <- filter_margins(x, feature_names)
  y <- y[feature_names, , drop = FALSE]

  plot_data <- data_for_plot(x, y, new_data, assay_name)
  p <- ggplot(
    plot_data$counts_df,
    aes(.data[[predictor[1]]], .data[[predictor[2]]], col = transform(value))
  ) +
    scale_x_continuous(expand = c(0, 0)) +
    scale_y_continuous(expand = c(0, 0)) +
    facet_wrap(~feature)

  if (!is.null(plot_data$links)) {
    l <- left_join(plot_data$links, new_data, by = "newdata_index")
    args <- list(
      data = l,
      mapping = aes(col = transform(mu), fill = transform(mu))
    ) |>
      modifyList(tile_opts)
    p <- p +
      do.call(geom_tile, args) +
      scale_fill_continuous(guide = "none")
  }

  p +
    do.call(
      geom_point,
      modifyList(
        point_opts, list(col = "black", size = point_opts$size * 2)
      )
    ) +
    do.call(geom_point, point_opts)
}

#' Faceting Helper
#'
#' When we visualize both real and simulated data, we want to use facet_grid
#' with separate rows for the real vs. simulated data. If we only have one of
#' these sources, then we can use facet_wrap to separate only across the genomic
#' features.
#'
#' @param p A ggplot2 object that we might want to facet.
#' @param n_sources The number of sources available.
#' @returns A ggplot2 graphics object with the appropriate faceting applied.
#' @examples
#' x <- data.frame(u = runif(500), feature = rep(LETTERS[1:10], 50))
#' (ggplot(x) +
#'   geom_histogram(aes(u))) |>
#'   facet_sources()
#'
#' x <- data.frame(
#'   u = runif(500),
#'   feature = rep(LETTERS[1:10], 50),
#'   source = rep(LETTERS[1:2], each = 250)
#' )
#' (ggplot(x) +
#'   geom_histogram(aes(u))) |>
#'   facet_sources(n_sources = 2)
facet_sources <- function(p, n_sources = 1) {
  if (n_sources > 1) {
    return(p + facet_grid(source ~ feature))
  }
  p + facet_wrap(~feature)
}

#' Plot against a Conditioning Variable
#'
#' We can evaluate the quality of a simulator's estimates by creating small
#' multiples plots of the fitted model over the observed data. This function
#' helps generate line plots of the LSS regression curves over the variables
#' in the link formula for the LSS model. Compared to `plot_univariate_`, this
#' function makes it possible to simultaneously overlay real with simulated
#' data. That is, we can overlay parameter estimates on two experiments
#' simultaneously.
#'
#' @param x A fitted object of class `MarginalCollection`. This contains the
#'   parameter estimates that we want to visualize as a function of conditioning
#'   colData.
#' @param y A SummarizedExperiment containing samples that we want to visualize
#'   (usually for comparison with the parameter estimates) from `x`.
#' @param predictor What variable should go on the x-axis of each small multiple
#'   plot? Defaults to the first variable in the colData of `y`.
#' @param simulated A SummarizedExperiment containing simulated data that we
#'   want to superimpose over the real data and fitted LSS estimates.
#' @param color What variable should be used to color in each sample or
#'   regression curve? Defaults to no color.
#' @param new_data The locations at which we would like to evaluate the
#'   parameters stored in `x`; i.e., the conditioning data for the parameter
#'   visualization.
#' @param feature_names A subset of the features of interest. We will try to
#'   select as many of these as possible, up to the constraint imposed by
#'   max_print.
#' @param ... Other arguments passed to plot_univariate_
#' @return A ggplot2 graphics object. You can access the data associated with
#'   the plot by calling $data and $layers[[i]]$data on the output, just like
#'   any ggplot2 object.
#' @importFrom dplyr left_join
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(
#'   exper,
#'   link = ~ ns(pseudotime),
#'   family = ~ gamlss.dist::NO()
#' ) |>
#'   estimate(exper)
#' samples <- sample(margins)
#' plot_univariate(margins, exper, "pseudotime", samples)
#' plot_univariate(margins, exper, "pseudotime", samples, "cell_type")
#' p <- plot_univariate(margins, exper, "pseudotime", samples)
#' p$data
#' p$layers[[1]]$data
#' p$layers[[2]]$data
#' @importFrom ggplot2 %+%
#' @export
#' @seealso [plot_univariate_]
plot_univariate <- function(x, y, predictor = NULL, simulated = NULL,
                            color = NULL, new_data = NULL, feature_names = NULL,
                            max_print = 8, ...) {
  f <- function(z) {
    plot_univariate_(
      x, z, predictor, color, new_data,
      feature_names = feature_names,
      max_print = max_print, ...
    )
  }
  args <- list("Real Data" = y)
  if (!is.null(simulated)) {
    args[["simulated"]] <- simulated
  }

  univariate_plots <- map(args, f)
  combined_data <- map_dfr(univariate_plots, ~ .$data, .id = "source")
  layers <- univariate_plots[[1]]$layers
  (ggplot(combined_data, univariate_plots[[1]]$mapping) + layers) |>
    facet_sources(n_distinct(combined_data$source))
}

#' Convert an Experiment into a Long Data Frame
#'
#' For visualization, we often need to apply `pivot_longer` to the assays in a
#' summarized experiment, so that each graphical mark corresponds to one row in
#' the input visualization data.frame.
#' @param se A SummarizedExperiment whose assay we want to convert to tidy
#'   "long" format.
#' @param keep_cols Which colData features do we want to include in the final
#'   output?
#' @param assay_names The specific assays within the experiment that we would
#'   like to extract and reshape.
#' @return A data.frame with the original assay data reformatted into "long"
#'   form, so that all gene names are stored in a variable "feature" and all
#'   values are stored in a variable "value".
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' pivot_experiment(exper)
#' pivot_experiment(exper, c("pseudotime"))
#' @export
pivot_experiment <- function(se, keep_cols = NULL, assay_names = NULL) {
  if (is.null(keep_cols)) {
    keep_cols <- colnames(colData(se))
  }
  if (is.null(assay_names)) {
    assay_names <- assayNames(se)[1]
  }

  col_data <- colData(se) |>
    as_tibble() |>
    select(any_of(keep_cols)) |>
    mutate(newdata_index = row_number())
  assay_data <- filter_assays(se, assay_names)

  map_dfr(assay_data, ~ {
    t(as.matrix(.)) |>
      as_tibble() |>
      mutate(newdata_index = row_number()) |>
      pivot_longer(-newdata_index, names_to = "feature") |>
      mutate(feature = factor(feature, levels = unique(feature)))
  }, .id = "replicate") |>
    left_join(col_data)
}

#' Visualize Conditioning in a Joint Distribution
#'
#' This wraps plot_univariate so that the plot method can be applied to a
#' `JointDistribution` object (not just a `MarginalCollection`).
#' @param x An object of class `JointDistribution` whose fitted LSS models we
#'   would like to overlay on the underlying experimental template data.
#' @param y The conditioning variable we would like to plot the samples and
#'   regression functions against.
#' @seealso [plot_univariate], [JointDistribution]
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' simulator <- setup_simulator(
#'   exper, ~pseudotime, ~ gamboostLSS::GaussianLSS(), copula_glasso()
#' ) |>
#'   estimate()
#' plot_joint_estimates(simulator, "pseudotime")
#' @export
plot_joint_estimates <- function(x, y = NULL, ...) {
  plot_univariate(x@margins, x@template, predictor = y, ...)
}

#' Default Plots for Marginal Collection
#' @seealso [plot_univariate]
#' @exportMethod plot
setMethod("plot", "MarginalCollection", plot_univariate)

#' Default Plots for Marginal Collection
#' @seealso [plot_joint_estimates]
#' @exportMethod plot
setMethod("plot", "JointDistribution", plot_joint_estimates)
