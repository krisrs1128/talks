#' Simulated Data for Testing
#'
#' This creates a toy SummarizedExperiment object. It is used to help test the
#' package.
#' @export
dummy_data <- function(n, p, sampler = rpois, ...) {
  col_data <- S4Vectors::DataFrame(
    cell_type = rep(c("A", "B"), each = ceiling(n / 2)),
    pseudotime = runif(n)
  )

  x <- matrix(sampler(n * p, ...), p, n)
  rownames(x) <- glue::glue("gene_{seq_len(p)}")

  SummarizedExperiment::SummarizedExperiment(
    assays = S4Vectors::SimpleList(counts = x),
    colData = col_data[seq_len(n), ]
  )
}

simulator_wrapper <- function(exper, ...) {
  setup_simulator(
    exper,
    ~ splines::ns(pseudotime, df = 3) * cell_type,
    ...
  ) |>
    estimate(mstop = 5, nu = 0.05)
}
