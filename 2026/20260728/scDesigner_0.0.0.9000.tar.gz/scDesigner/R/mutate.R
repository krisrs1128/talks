#' Modify Plan's Distributional Family
#'
#' This will replace all families within a `MarginalCollection`'s plan.
#' This makes it possible to re-estimate a simulator with all simulation
#' hyperparameters fixed except for the features' distributional family.
#' @param plan The plan slot from an object of class `MarginalCollection`.
#' @param family The new distributional family to substitute in the `family`
#'   column of the plan.
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper)
#' margins # ZINBLSS family
#' mutate_family(margins@plan, ~ gamboostLSS::GaussianLSS())
#' @importFrom purrr map
#' @export
mutate_family <- function(plan, family) {
  ix <- seq_len(nrow(plan))
  if (!is.list(family)) {
    field(plan$family, "family") <- map(ix, family)
  } else {
    field(plan$family, "family") <- family
  }

  plan
}

#' Modify Plan's Link Functions
#'
#' This will replace all links within a `MarginalCollection`'s plan. This makes
#' it possible to re-estimate a simulator with all simulation hyperparameters
#' fixed except for the conditioning defined the link function.
#' @param plan The plan slot from an object of class `MarginalCollection`.
#' @param link The new link function to substitute in the `link` column of the
#'   plan.
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper)
#' margins # ~1, only intercept
#' mutate_links(margins@plan, ~pseudotime)
#' @export
mutate_links <- function(plan, link) {
  if (is_formula(link)) {
    field(plan$link, "links") <- rep(list(link), nrow(plan))
  } else if (is_formula(link[[1]])) {
    fnames <- names(link)

    new_links <- list()
    for (i in seq_len(nrow(plan))) {
      if (is.null(names(plan$link[[i]]))) {
        new_links[[i]] <- link
      } else {
        tmp <- list()
        for (j in seq_along(fnames)) {
          tmp[[fnames[j]]] <- link[fnames[j]]
        }
        new_links[[i]] <- tmp
      }
    }

    field(plan$link, "links") <- new_links
  }

  plan
}

#' Highlight Plan Overlaps
#'
#' When we mutate a plan, we want to highlight the changes that have been made.
#' We accomplish this by overwriting the mutated plan onto the original one, but
#' highlighting the feature names that have been changed.
#' @param plan The original plan which had been mutated.
#' @param new_plan The new plan whose changes we want to highlight.
#' @return A version of the original plan with all features from `new_plan`
#'   highlighted.
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper, family = ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' interleave_plan(margins@plan, margins@plan[1:10])
interleave_plan <- function(plan, new_plan) {
  match_ix <- which(field(plan$feature, "gene_ids") %in% field(new_plan$feature, "gene_ids"))
  plan[match_ix, ] <- new_plan

  cur_highlight <- field(plan$feature, "highlight")
  cur_highlight[match_ix] <- TRUE
  field(plan$feature, "highlight") <- cur_highlight
  plan
}

#' Change Family or Link within a Plan
#'
#' Manipulate the specification of an existing `MarginalCollection`. For
#' example, we can use different distributional families or conditioning links
#' for different sets of genes, selected using `tidyselect` syntax.
#'
#' @param .data An object of class `MarginalCollection` whose plan we want to
#'   modify.
#' @param features The subset of features to mutate. Must be specified using
#'   `tidyselect` syntax.
#' @param family The new distributional family to substitute in the `family`
#'   column of the plan.
#' @param link The new link function to substitute in the `link` column of the
#'   plan.
#' @return A version of the original `MarginalCollection` with families and link
#'   functions modified for the selected subset of features.
#' @importFrom rlang duplicate
#' @importFrom dplyr select
#' @seealso [setup_margins]
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper)
#' mutate_marginals(margins, matches("_[1-4]"), family = ~ gamlss.dist::NO())
#' mutate_marginals(margins, ends_with("3"), link = ~ ns(pseudotime))
#' mutate_marginals(margins, 4:5, link = ~ ns(pseudotime))
#' @export
mutate_marginals <- function(.data, features = everything(), family = NULL,
                             link = NULL) {
  .data_ <- duplicate(.data)
  plan <- .data_@plan
  all_features <- field(plan$feature, "gene_ids")

  selection <- setNames(rep(TRUE, nrow(plan)), all_features) |>
    t() |>
    as_tibble() |>
    select(!!enquo(features)) |>
    colnames()

  new_plan <- plan[all_features %in% selection, ]
  if (!is.null(family)) {
    new_plan <- mutate_family(new_plan, family)
  }

  if (!is.null(link)) {
    new_plan <- mutate_links(new_plan, link)
  }

  .data_@plan <- interleave_plan(plan, new_plan)
  .data_
}

#' Mutate the Marginals within a Joint Distribution
#'
#' @param .data An object of class `JointDistribution` whose marginal plan we
#'   want to modify.
#' @param features The subset of features to mutate. Must be specified using
#'   `tidyselect` syntax.
#' @param family The new distributional family to substitute in the `family`
#'   column of the plan.
#' @param link The new link function to substitute in the `link` column of the
#'   plan.
#' @return A version of the original `JointDistribution` with families and link
#'   functions modified for the selected subset of features.
#' @export
mutate_joint <- function(.data, features = everything(), family = NULL,
                         link = NULL) {
  .data_ <- duplicate(.data)
  .data_@margins <- .data_@margins |>
    mutate_marginals(features = features, family, link)
  .data_
}

#' @importFrom glue glue
#' @importFrom purrr map_dbl
check_correlations <- function(correlations, .data) {
  if (attr(class(.data@dependence@fit[[1]]), "package") != "copula") {

  }

  fit_names <- names(.data@dependence@fit)
  n_features <- nrow(.data@margins@plan)

  if (!is.list(correlations)) {
    correlations <- list(correlations)
  }
  if (is.null(names(correlations))) {
    names(correlations) <- fit_names[seq_along(correlations)]
  }
  if (!(all(names(correlations) %in% fit_names))) {
    cli_abort("Some named correlations are not in the fitted copula")
  }

  corr_rows <- map_dbl(correlations, nrow)
  if (!(all(corr_rows == n_features))) {
    bad_ix <- which(corr_rows != n_features)
    cli_abort(glue("The correlation matrix {bad_ix} has an incorrect number of features."))
  }

  correlations
}

#' Modify Copula Correlations
#' @export
mutate_correlation <- function(.data, correlations) {
  correlations <- check_correlations(correlations, .data)
  reorder_names <- match(names(correlations), names(.data@dependence@fit))
  correlations <- correlations[reorder_names]

  # change the correlation matrices in each fit
  for (i in seq_along(correlations)) {
    corr_i <- correlations[[i]][lower.tri(correlations[[i]])]
    .data@dependence@fit[[i]]@parameters[seq_along(corr_i)] <- corr_i
  }

  # update the samplers
  environment(.data@dependence@sampler)$copulas <- .data@dependence@fit
  .data
}

setGeneric("mutate", function(.data, ...) {})

#' Change Family or Link within a Plan
#'
#' Manipulate the specification of an existing `MarginalCollection`. For
#' example, we can use different distributional families or conditioning links
#' for different sets of genes, selected using `tidyselect` syntax.
#' @seealso [mutate_marginals]
#' @export
setMethod(
  "mutate",
  signature = "MarginalCollection",
  definition = mutate_marginals
)

#' Mutate the Marginals within a Joint Distribution
#'
#' @seealso [mutate_joint]
#' @export
setMethod("mutate", signature = "JointDistribution", definition = mutate_joint)
