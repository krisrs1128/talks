#' Introduce Spatial Coordinates into `colData`
#'
#' This augments the `colData` from a spatial experiment to also include the `x`
#' and `y` coordinates from the spatial experiment.
#' @param experiment A spatial experiment containing coordinates that we would
#'   like to add to the `colData`.
#' @return experiment A version of `experiment` that also includes `x` and `y`
#'   spatial coordinates in the updated `colData`.
#' @importFrom SpatialExperiment spatialCoords
#' @examples
#' exper <- STexampleData::ST_mouseOB()
#' augmented <- augment_spatial(exper)
#' setdiff(colnames(colData(augmented)), colnames(colData(exper)))
augment_spatial <- function(experiment) {
  colData(experiment) <- cbind(colData(experiment), spatialCoords(experiment))
  experiment
}

#' Introduce PCs
#'
#' @examples
#' exper <- dummy_data(10, 20, 10)
#' exper <- augment_pca(exper)
#' colData(exper)
#' @export
augment_pca <- function(experiment, K = 2) {
  z <- princomp(t(assay(experiment)))$scores[, seq_len(K)]
  colnames(z) <- paste0("PC", seq_len(K))
  colData(experiment) <- cbind(colData(experiment), z)
  experiment
}

#' Introduce MDS Dimensions
#'
#' @importFrom SummarizedExperiment colData<- colData
#' @examples
#' exper <- dummy_data(10, 20, 10)
#' exper <- augment_mds(exper)
#' colData(exper)
#' @export
augment_mds <- function(experiment, K = 2, dist_fun = dist, scale_data = TRUE) {
  x <- t(assay(experiment))
  if (scale_data) {
    x <- scale(x)
  }

  z <- cmdscale(dist_fun(x), k = K)
  colnames(z) <- paste0("MDS", seq_len(K))
  colData(experiment) <- cbind(colData(experiment), z)
  experiment
}

setGeneric("augment", function(experiment, ...) experiment)

#' Augment the `colData` of a Spatial Experiment
#'
#' This augments the `colData` from a spatial experiment to also include the `x`
#' and `y` coordinates from the spatial experiment.
#' @importClassesFrom SpatialExperiment SpatialExperiment
#' @export
setMethod("augment", "SpatialExperiment", augment_spatial)
