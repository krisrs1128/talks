#' Representation of a Joint Distribution
#'
#' `scDesigner` represents a multivariate distribution by tying together a
#' collection of Location-Shape-Scale conditional marginal distributions
#' marginal distributions through a parametric copula. This object represents
#' that connection between marginals.
#'
#' @slot margins An object of class `MarginalCollection`.
#' @slot dependence A list with names `copula` and `sample` that can be used to
#'   estimate and sample from a copula model. See `copula_gassian` or
#'   `copula_vine` for examples of function factories that create these inputs.
#' @slot template A SummarizedExperiment with which the joint distribution can
#'   be estimated. This supports convenience functions downstream, so that
#'   estimation and plotting functions don't have to repeatedly request the
#'   experimental data as input.
#' @seealso [MarginalCollection]
#' @exportClass JointDistribution
#' @examples
#' exper <- dummy_data(20, 10, lambda = 10)
#' margins <- setup_margins(exper, ~cell_type)
#' new(
#'   "JointDistribution",
#'   margins = margins,
#'   dependence = copula_gaussian(),
#'   template = exper
#' )
setClass(
  "JointDistribution",
  representation(
    margins = "MarginalCollection",
    dependence = "Copula",
    template = "SummarizedExperiment"
  )
)

#' Allow copula components to be `NULL`
setClassUnion("functionOrNull", members = c("function", "NULL"))

#' Represent a Copula
#'
#' This class offers a unified representation of both vine and elliptical (e.g.,
#' t and Gaussian) copulas from the rvinecopulib and copula libraries,
#' respectively.
#'
#' @slot estimator A function that estimates the a copula from data, based on
#'   (1) the conditional marginal distributions in a `MarginalCollection`, (2)
#'   the experimental assay data on which to learn the copula, and (3) the
#'   colData that used in the link functions in (1).
#' @slot fit The fitted copula object, from either vine or elliptical copula
#'   families.
#' @slot sampler A function that can be used to sample form the copula,
#'   conditional on new data as specified in the marginal collection's link
#'   functions.
setClass(
  "Copula",
  representation(
    estimator = "function",
    fit = "ANY",
    sampler = "functionOrNull"
  )
)

#' Define a Multivariate Simulator
#'
#' This sets up a multivariate simulator for later estimation and sampling. This
#' object can be manipulated even before estimation (e.g., changing regression
#' formulas for specific genes). It can later be estimated using `estimate` and
#' sampled using `sample`.
#'
#' @param experiment A SummarizedExperiment object to use as the simulation
#'   template. The rownames will be used as features in the MarginalCollection.
#'   The associated assays will also be used as the default estimation data,
#'   unless they are replaced beforehand.
#' @param link_formula The regression formula to apply to all features. This can
#'   be customized using `mutate`. Defaults to `~1`, a separate intercept for
#'   each gene.
#' @param family The distributional family to use when estimating the marginal
#'   LSS models. Currently, we support families from the gamlss.dist and
#'   gamboostLSS packages.
#' @param copula_def The Copula object to use in downstream multivariate
#'   dependence modeling. Defaults to a Gaussian copula with sample covariance
#'   estimation (`copula_gaussian`).
#' @return An object of class `JointDistribution`, storing the plans for LSS
#'   regression and Copula dependence models as well as the template
#'   experimental data for estimation.
#' @seealso [estimate], [sample]
#' @examples
#' exper <- dummy_data(200, 10, lambda = 10)
#' sim <- setup_simulator(exper, ~pseudotime, ~ gamlss.dist::NO())
#' sim
#'
#' estimate(sim)
#' plot(sim, "pseudotime")
#'
#' sim <- setup_simulator(
#'   exper,
#'   ~ ns(pseudotime, df = 20),
#'   ~ gamboostLSS::GaussianLSS(),
#'   copula = copula_adaptive(~cell_type)
#' ) |>
#'   estimate(nu = 0.1)
#' plot(sim, "pseudotime", transform = identity)
#' @export
setup_simulator <- function(experiment, link_formula, family,
                            copula_def = NULL) {
  if (is.null(copula_def)) {
    copula_def <- copula_gaussian(~1)
  }

  margins <- setup_margins(experiment, link_formula, family)
  new(
    "JointDistribution",
    margins = margins,
    dependence = copula_def,
    template = experiment
  )
}

#' Sample from a Joint Distribution
#'
#' This samples from a fitted `JointDistribution`, which includes both the
#' marginal conditional distributions for each genomic feature and the copula
#' model that encodes their dependence.
#'
#' @param marginal_collection An object of class `MarginalCollection` containing
#'   the estimated marginal models. If `newdata` is not provided, this marginal
#'   collection must also include a default `col_data` slot.
#' @param copula An object of class `Copula` with nonnull `sampler` slot. This
#'   reflects the multivariate dependence structure in the estimated models.
#' @param n How many replicates to draw? Defaults to 1.
#' @param new_data The colData on which to condition the new samples. This must
#'   include all columns that are present in the formula defining the
#'   conditional distribution for the object. By default, this is set to NULL,
#'   meaning that it will draw samples at the same coordinates as the original
#'   fit.
#' @return An object of class `SummarizedExperiment` containing the simulated
#'   features in `assay` and conditioning new data in the `colData` slot.
#'   Multiple replicates will be represented as separate `counts` assays within
#'   the experiments `assayList` assays within the experiments `assayList`.
#' @importFrom tidyr pivot_longer
#' @importFrom purrr set_names
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' sim <- setup_simulator(
#'   exper,
#'   ~ splines::ns(pseudotime, df = 3) * cell_type,
#'   ~ gamboostLSS::GaussianLSS()
#' ) |>
#'   estimate(mstop = 5, nu = 0.05)
#' sample_joint(sim@margins, sim@dependence)
#' @export
sample_joint <- function(marginal_collection, copula = NULL, n = 1,
                         new_data = NULL) {
  if (is.null(new_data)) {
    new_data <- default_coldata(marginal_collection)
  }
  if (n != 1) {
    new_data <- replicate(n, new_data, simplify = FALSE) |>
      bind_rows()
  }
  n_new <- nrow(new_data)
  n_features <- length(marginal_collection@estimates)

  if (is.null(copula)) {
    u <- matrix(runif(n_new * n_features), n_new, n_features)
  } else {
    u <- copula@sampler(new_data)
  }

  # get all data, stacked
  result <- matrix(NA, n_new, n_features)
  for (j in seq_len(n_features)) {
    result[, j] <- quantile_marginal(
      marginal_collection@estimates[[j]],
      new_data,
      u[, j]
    )$value
  }

  # unstack and build into a SummarizedExperiment
  samples_to_experiment(
    result,
    select(marginal_collection@plan, feature),
    new_data
  )
}

#' Sample from a Joint Distribution
#'
#' This allows the `sample_joint` function to be called using the sample syntax
#' as the base R `sample` generic. We split the joint distribution object into
#' its margins and dependence to form the input to `sample_joint`.
#'
#' @seealso [sample_joint]
#' @export
setMethod("sample", "JointDistribution", function(x, size, new_data = NULL, ...) {
  if (missing(size)) {
    size <- 1
  }
  sample_joint(x@margins, x@dependence, new_data = new_data, n = size)
})

#' Uniformize a Table of Marginal Distributions
#'
#' This draws from F^{-1}(y[i] | x[i]) in order to uniformize the gene
#' expressions y[i] according to the conditioning column data x[i].
#'
#' @param marginal_collection An object of class `MarginalCollection` containing
#'   the estimated marginal models. If `newdata` is not provided, this marginal
#'   collection must also include a default `col_data` slot.
#' @param template The assay data on which the observed marginal quantiles will
#'   be conditioned.
#' @return A matrix of dimension n_samples x n_features with values between 0
#'   and 1. Marginally, each feature should be approximately uniform.
#' @export
uniformize <- function(marginal_collection, template) {
  n_features <- ncol(template)
  result <- matrix(NA, nrow(template), n_features)
  for (j in seq_len(n_features)) {
    result[, j] <- cdf_marginal(
      marginal_collection@estimates[[j]],
      NULL,
      template[, j]
    )$value
  }

  result
}

#' Sample a collection of Copulas
#'
#' We may want to estimate different correlation structures across groups of
#' cells/samples. When we later sample new correlation structures, we need to
#' ensure we draw from the correct copula. We support grouping for either
#' elliptical or vine copulas.
#'
#' @param copulas A list containing all the fitted copulas for each group
#'   defined in the link.
#' @param n_features The dimensionality of the output samples. E.g., the number
#'   of genes observed within each sample.
#' @param link A formula object defining the conditional dependence between the
#'   copula and features of the underlying experiment. For example, `~Treatment`
#'   means that different multivariate dependencies will be learned for the
#'   treatment and control groups.
#' @param new_data The colData on which to condition the new samples. This must
#'   include all columns that are present in the formula defining the
#'   conditional distribution for the object. By default, this is set to NULL,
#'   meaning that it will draw samples at the same coordinates as the original
#'   fit.
#' @param copula_type Either "elliptical" or "vine" describing the type of the
#'   copula in the first argument.
#' @importFrom copula rCopula
#' @importFrom rvinecopulib rvine
#' @examples
#' exper <- dummy_data(10, 20, rpois, lambda = 10)
#' simulator <- setup_simulator(
#'   exper, ~ splines::ns(pseudotime, df = 3) * cell_type,
#'   ~ gamboostLSS::GaussianLSS()
#' ) |>
#'   estimate(mstop = 5, nu = 0.05)
#' sample_copulas(simulator@dependence@fit, 20, new_data = colData(exper))
sample_copulas <- function(copulas, n_features, link = ~1, new_data = NULL,
                           copula_type = "elliptical") {
  # what are the new data's groups?
  patterns <- formula_patterns(link, new_data)
  distinct <- unique(patterns)

  # draw samples for each copula
  result <- matrix(nrow = nrow(new_data), ncol = n_features)
  for (i in seq_along(distinct)) {
    ix <- which(patterns == distinct[i])

    if (copula_type == "elliptical") {
      result[ix, ] <- rCopula(length(ix), copulas[[distinct[i]]]) |>
        suppressWarnings()
    } else if (copula_type == "vine") {
      result[ix, ] <- truncate(rvine(length(ix), copulas[[distinct[i]]]))
    } else {
      cli_abort("`copula_type` argument must be either 'elliptical' or 'vine'.")
    }
  }
  result
}

#' Represent Elliptical Copulas
#'
#' This is the function underlying `copula_gaussian()` and `copula_t()`. It
#' supports estimation and sampling for copulas from the `copula` library.
#' Separate multivariate dependence can be estimated for different groups by
#' including the group specification in the link.
#'
#' @param link A formula object defining the conditional dependence between the
#'   copula and features of the underlying experiment. For example, `~Treatment`
#'   means that different multivariate dependencies will be learned for the
#'   treatment and control groups.
#' @param cov A function used to estimate covariance on the transformed
#'   quantile variates. Defaults to sample covariance. Customizing this function
#'   makes it possible to use high-dimensional covariance or graphical lasso
#'   estimation.
#' @param copula The `copula` library object used for estimation. Defaults to
#'   `normalCopula`.
#' @param quantile_fun The function used to map from uniform variates to either
#'   the variables used in covariance estimation. Defaults to `qnorm()`, as in
#'   Gaussian copulas.
#' @return An object of class `Copula`, which includes slots for estimation,
#'   sampling, and storing fitted parameters.
#' @seealso [copula_gaussian], [copula_t]
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper, ~pseudotime, ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' cop <- copula_elliptical()
#' res <- cop@estimator(margins, t(assay(exper)), colData(exper))
#' res$sampler(colData(exper))
copula_elliptical <- function(link = ~1, cov_fun = cov, copula = normalCopula,
                              quantile_fun = \(u) qnorm(u)) {
  estimator <- \(marginal_collection, template, col_data = NULL) {
    n_features <- ncol(template)
    if (is.null(marginal_collection@estimates)) {
      cli_abort("Cannot estimate Copula model before marginals.")
    }

    variates <- quantile_fun(uniformize(marginal_collection, template))
    cov_fit <- covariance_model(variates, col_data, link, cov_fun)
    copulas <- map(cov_fit@sigmas, cov2cor) |>
      map(~ copula(.[lower.tri(.)], dim = n_features, dispstr = "un"))

    sampler <- \(new_data = NULL) {
      if (is.null(new_data)) {
        new_data <- default_coldata(marginal_collection)
      }
      sample_copulas(copulas, n_features, link, new_data)
    }
    list(fit = copulas, sampler = sampler)
  }
  new("Copula", estimator = estimator, fit = NULL, sampler = NULL)
}

#' Represent a Gaussian Copula
#'
#' This function returns a `Copula` object with methods for estimating and
#' sampling from Gaussian copulas. These copulas have easily interpretable
#' second moment structure. Separate multivariate dependence can be estimated
#' for different groups by including the group specification in the link.
#'
#' @param link A formula object defining the conditional dependence between the
#'   copula and features of the underlying experiment. For example, `~Treatment`
#'   means that different multivariate dependencies will be learned for the
#'   treatment and control groups.
#' @param cov A function used to estimate covariance on the transformed
#'   quantile variates. Defaults to sample covariance. Customizing this function
#'   makes it possible to use high-dimensional covariance or graphical lasso
#'   estimation.
#' @return An object of class `Copula`, which includes slots for estimation,
#'   sampling, and storing fitted parameters.
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper, ~pseudotime, ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' cop <- copula_gaussian()
#' res <- cop@estimator(margins, t(assay(exper)), colData(exper))
#' res$sampler(colData(exper))
#' @importFrom copula normalCopula
#' @seealso [copula_t], [copula_glasso], [copula_glasso_t], [copula_adaptive],
#'   [copula_adaptive_t], [copula_elliptical]
#' @export
copula_gaussian <- function(link = ~1, cov_fun = cov) {
  copula_elliptical(link, cov_fun, normalCopula)
}

#' Represent a Student's t Copula
#'
#' This function returns a `Copula` object with methods for estimating and
#' sampling from t copulas. These copulas have attractive tail dependence
#' properties. Separate multivariate dependence can be estimated for different
#' groups by including the group specification in the link.
#'
#' @param link A formula object defining the conditional dependence between the
#'   copula and features of the underlying experiment. For example, `~Treatment`
#'   means that different multivariate dependencies will be learned for the
#'   treatment and control groups.
#' @param cov A function used to estimate covariance on the transformed
#'   quantile variates. Defaults to sample covariance. Customizing this function
#'   makes it possible to use high-dimensional covariance or graphical lasso
#'   estimation.
#' @param df The degrees of freedom to use when mapping F^{-1}(y[i] | x[i]) in
#'   t-variate generation.
#' @return An object of class `Copula`, which includes slots for estimation,
#'   sampling, and storing fitted parameters.
#' @seealso [copula_gaussian], [copula_glasso], [copula_glasso_t],
#'   [copula_adaptive], [copula_adaptive_t], [copula_elliptical]
#' @importFrom copula tCopula
#' @export
copula_t <- function(link = ~1, cov_fun = cov, df = 20) {
  copula_elliptical(link, cov_fun, tCopula, \(u) qt(u, df))
}

#' Gaussian Copula with High-Dimensional Covariance Estimation
#'
#' This uses Cai and Liu (2011)'s adaptive threshold covariance estimation to
#' estimate the covariance in a Gaussian Copula. This can have improved
#' properties in high-dimensional settings.
#'
#' @param link A formula object defining the conditional dependence between the
#'   copula and features of the underlying experiment. For example, `~Treatment`
#'   means that different multivariate dependencies will be learned for the
#'   treatment and control groups.
#' @seealso [copula_gaussian], [copula_glasso], [copula_glasso_t], [copula_t],
#'   [copula_adaptive_t], [copula_elliptical]
#' @importFrom CovTools CovEst.adaptive
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper, ~pseudotime, ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' cop <- copula_adaptive()
#' res <- cop@estimator(margins, t(assay(exper)), colData(exper))
#' res$sampler(colData(exper))
#'
#' simulator <- setup_simulator(
#'   exper, ~pseudotime, ~ gamboostLSS::GaussianLSS(), copula_adaptive()
#' ) |>
#'   estimate()
#' @export
copula_adaptive <- function(link = ~1, ...) {
  cov_fun <- \(x) CovEst.adaptive(x, ...)$S
  copula_gaussian(link, cov_fun)
}

#' Student T Copula with High-Dimensional Covariance Estimation
#'
#' This uses Cai and Liu (2011)'s adaptive threshold covariance estimation to
#' estimate the covariance in a Student T Copula. This can have improved
#' properties in high-dimensional settings. The T copula can have improved tail
#' dependence properties, but it requires additional tuning of the '
#' degrees-of-freedom parameter.
#'
#' @param link A formula object defining the conditional dependence between the
#'   copula and features of the underlying experiment. For example, `~Treatment`
#'   means that different multivariate dependencies will be learned for the
#'   treatment and control groups.
#' @seealso [copula_gaussian], [copula_glasso], [copula_glasso_t], [copula_t],
#'   [copula_adaptive], [copula_elliptical]
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper, ~pseudotime, ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' cop <- copula_adaptive_t()
#' res <- cop@estimator(margins, t(assay(exper)), colData(exper))
#' res$sampler(colData(exper))
#'
#' simulator <- setup_simulator(
#'   exper, ~pseudotime, ~ gamboostLSS::GaussianLSS(), copula_adaptive_t()
#' ) |>
#'   estimate()
#' @export
copula_adaptive_t <- function(link = ~1, df = 20, ...) {
  cov_fun <- \(x) CovEst.adaptive(x, ...)$S
  copula_t(link, cov_fun, df = df)
}

#' Graphical Lasso Defaults
#'
#' This defines defaults for precision matrix estimation using the
#' `CovTools::PreEst.glasso()` function. By default, we use BIC to choose the
#' regularization strength, using a (small) grid of 5 lambdas ranging from 0.01
#' to 100.
#' @param ... Named parameters to over-ride the hyperparameter defaults for
#'   graphical lasso estimation.
glasso_defaults <- function(...) {
  defaults <- list(
    method = list(type = "BIC", param = 10^seq(-2, 2, length.out = 5))
  )
  modifyList(defaults, list(...))$method
}

#' Gaussian Copula with Graphical Lasso Precision Estimation
#'
#' Use a graphical lasso when estimating a Gaussian Copula. This is useful in
#' high-dimensional settings, where we imagine the standard sample covariance
#' estimator might be poorly conditioned.
#'
#' @param link A formula object defining the conditional dependence between the
#'   copula and features of the underlying experiment. For example, `~Treatment`
#'   means that different multivariate dependencies will be learned for the
#'   treatment and control groups.
#' @param hard_thresh Any precision estimates with value below this number will
#'   be thresholded to exactly zero. This is is useful for establishing ground
#'   truth in simulation of partial correlation networks and addresses the fact
#'   that, even on convergence, some very small precision estimate may remain.
#' @param ... Other parameters passed into `glasso_defaults()`. This can be used
#'   to adjust the glasso regularization strength, for example.
#' @examples
#' exper <- dummy_data(10, 20, lambda = 10)
#' margins <- setup_margins(exper, ~pseudotime, ~ gamboostLSS::GaussianLSS()) |>
#'   estimate(exper)
#' cop <- copula_glasso()
#' res <- cop@estimator(margins, t(assay(exper)), colData(exper))
#' res$sampler(colData(exper))
#'
#' simulator <- setup_simulator(
#'   exper, ~pseudotime, ~ gamboostLSS::GaussianLSS(), copula_glasso()
#' ) |>
#'   estimate()
#' @export
copula_glasso <- function(link = ~1, hard_thresh = 1e-5, ...) {
  opts <- glasso_defaults(...)
  copula_gaussian(link, \(x) glasso_cov(x, opts, hard_thresh))
}

#' Student's T Copula with Graphical Lasso Precision Estimation
#'
#' Use a graphical lasso when estimating a Student's T Copula. This is useful in
#' high-dimensional settings, where we imagine the standard sample covariance
#' estimator might be poorly conditioned. The Student's T Copula also has
#' attractive tail dependence properties.
#'
#' @param link A formula object defining the conditional dependence between the
#'   copula and features of the underlying experiment. For example, `~Treatment`
#'   means that different multivariate dependencies will be learned for the
#'   treatment and control groups.
#' @param ... Other parameters passed into `glasso_defaults()`. This can be used
#'   to adjust the glasso regularization strength, for example.
#' @export
copula_glasso_t <- function(link = ~1, hard_thresh = 1e-5, df = 20, ...) {
  opts <- glasso_defaults(...)
  copula_t(link, \(x) glasso_cov(x, opts, hard_thresh), df = df)
}

#' Represent a Vine Copula
#'
#' This provides estimation methods, fits, and samplers for Vine Copulas. These
#' are an attractive option for capturing higher-order dependencies in
#' multivariate distributions. Note that this estimation strategy can be much
#' more time consuming than the covariance-based Copulas in high-dimensional
#' settings.
#'
#' @param link A formula object defining the conditional dependence between the
#'   copula and features of the underlying experiment. For example, `~Treatment`
#'   means that different multivariate dependencies will be learned for the
#'   treatment and control groups.
#' @param ... Other parameters passed into the `copula_controls` argument to
#'   `vine` in the estimation step.
#' @return An object of class `Copula`, which includes slots for estimation,
#'   sampling, and storing fitted parameters.
#' @importFrom rvinecopulib rvine vine
#' @export
copula_vine <- function(link = ~1, ...) {
  estimator <- \(marginal_collection, template, col_data = NULL) {
    n_features <- ncol(template)
    if (is.null(marginal_collection@estimates)) {
      cli_abort("Cannot estimate copula model before marginals.")
    }

    # generate copulas for each group
    copulas <- list()
    u <- uniformize(marginal_collection, template)
    g <- grouping_patterns(nrow(u), col_data, link)
    for (i in seq_along(g$distinct)) {
      copulas[[g$distinct[i]]] <- vine(
        u[which(g$patterns == g$distinct[i]), ],
        copula_controls = list(...)
      )
    }

    sampler <- \(new_data = NULL) {
      if (is.null(new_data)) {
        new_data <- default_coldata(marginal_collection)
      }
      sample_copulas(copulas, n_features, link, new_data, "vine")
    }
    list(fit = copulas, sampler = sampler)
  }
  new("Copula", estimator = estimator, fit = NULL, sampler = NULL)
}

#' Re-organize Samples into a SummarizedExperiment
#'
#' @param samples An (n samples * r replicates) by p features matrix of samples
#'   to map into a SummarizedExperiment object. We assume that the all samples
#'   for each replicate are stored together rowwise in this matrix.
#' @param features The p genomic features as represented in `feature` column of
#'   a `MarginalCollection`. The `gene_id` field of these features will be use
#'   to define rownames in the final SummarizedExperiment.
#' @param col_data The conditioning variables at which the samples were drawn.
#'   These will be stored in the col_data of the returned SummarizedExperiment.
#' @return An object of class `SummarizedExperiment`, storing the samples and
#'   descriptive sample information about them.
#' @importFrom SummarizedExperiment SummarizedExperiment
#' @importFrom tibble column_to_rownames
#' @examples
#' x <- matrix(rnorm(100 * 5), 100, 5)
#' features <- data.frame(feature = vctrs::new_rcrd(
#'   list(gene_ids = LETTERS[1:5], highlight = rep(T, 5)),
#'   class = "gene_id"
#' ))
#' z <- data.frame(treatment = c(rep("TRT", 5), rep("CNTRL", 5)))
#' samples_to_experiment(x, features, z)
samples_to_experiment <- function(samples, features, col_data) {
  n_new <- nrow(col_data)
  assay_data <- list()
  for (i in seq_len(nrow(samples) / n_new)) {
    assay_data[[glue("counts_{i}")]] <- t(samples[(n_new * (i - 1) + 1):(n_new * i), ])
  }

  row_data <- features |>
    mutate(feature = field(feature, "gene_ids")) |>
    column_to_rownames("feature")

  if ("newdata_index" %in% colnames(col_data)) {
    col_data <- col_data |>
      column_to_rownames("newdata_index")
  }

  SummarizedExperiment(assay_data, row_data, colData = col_data)
}

#' Helper Function to Hard Threshold
#'
#' @param x The matrix or vector whose values will be hard thresholded.
#' @param thresh The degree of thresholding. Any value whose absolute value less
#'   than this will be set to zero.
#' @examples
#' hist(hard_threshold(rnorm(1e4), .45), 40)
hard_threshold <- function(x, thresh = 0) {
  x[abs(x) < thresh] <- 0
  x
}

#' Helper Function to Truncate
#'
#' @param x The matrix or vector whose values will be hard thresholded.
#' @param lower Any value lower than this will be set to `lower`.
#' @param lower Any value larger than this will be set to `higher`.
#' @examples
#' hist(truncate(rnorm(1e4), -1.8, 1.8), 20)
truncate <- function(x, lower = 0, upper = 1) {
  x[x < lower] <- lower
  x[x > upper] <- upper
  x
}

#' Helper to Extract Copula Correlation
#'
#' @param simulator An object of class joint distribution containing a non-null
#'  `@dependence` slot.
#' @return If `@dependence@fit` is a one element list, this will return an
#'  object of either class matrix (if using the copula library) or '  `rvine_list`
#'  (if using rvinecopulib). Otherwise, it will return a list of objects from
#'  these classes, one for each copula object in @dependence@fit.
#' @examples
#' exper <- dummy_data(20, 10, lambda = 10)
#' simulator <- setup_simulator(
#'   exper, ~pseudotime, ~ gamboostLSS::GaussianLSS(), copula_vine()
#' ) |>
#'   estimate()
#' copula_parameters(simulator)
#' @importFrom copula p2P
#' @importFrom rvinecopulib get_all_parameters
#' @export
copula_parameters <- function(simulator) {
  fit_class <- class(simulator@dependence@fit[[1]])
  if (any(grepl("copula", tolower(fit_class)))) {
    extract_fun <- \(x) p2P(x@parameters)
  } else if ("vine" %in% fit_class) {
    extract_fun <- \(x) get_all_parameters(x)
  } else {
    cli_abort("Cannot extract parameters for a package not of class copula or vine.")
  }

  parameters <- map(simulator@dependence@fit, extract_fun)
  if (length(parameters) == 1) {
    parameters <- parameters[[1]]
  }
  parameters
}
