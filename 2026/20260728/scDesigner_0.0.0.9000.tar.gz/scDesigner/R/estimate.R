#' Substitute Response into Formula(s)
#'
#' Wrapper of `update` to replace formula response variables either for a single
#' or vector of formulas.
#'
#' @param fmla Either a formula object or a vector of formula objects. We want
#'   to replace the response variables in all these formula.
#' @param name The new response variable for the formula/formulas.
#' @return A formula or list of formulas, matching the input `fmla`, except with
#'   all the response variables replaced with `name`.
#' @examples
#' update_formula(Gene1 ~ treatment + pseudotime, "Gene2")
#' update_formula(
#'   list(
#'     f1 = Gene1 ~ treatment + pseudotime,
#'     f2 = Gene2 ~ treatment + pseudotime
#'   ),
#'   "y"
#' )
update_formula <- function(fmla, name) {
  if (!is.list(fmla)) {
    return(update(fmla, formula(glue("`{name}` ~ ."))))
  }

  params <- names(fmla)
  result <- list()
  for (j in seq_along(fmla)) {
    result[[params[[j]]]] <- update(fmla[[j]], formula(glue("`{name}` ~ .")))
  }
  result
}

#' Ensure Factor Columns
#'
#' Convert all character columns into factors. This is helpful for ensuring
#' consistent outputs when using `model.matrix`.
#' @param df A data.frame whose string columns we want to replace with factors.
#' @return A data.frame with string columns replaced.
#' @examples
#' df <- data.frame(test = c("A", "B", "B", "A"))
#' str(string_to_factor(df))
string_to_factor <- function(df) {
  char_ix <- sapply(df, is.character)
  df[char_ix] <- lapply(df[char_ix], as.factor)
  df
}

#' Regression Data for LSS Models
#'
#' This converts `SummarizedExperiment` and `MarginalCollection` representations
#' of a marginal simulator into the matrix and vector data that can be used as
#' arguments for Location-Shape-Scale regression models.
#'
#' @param experiment An object of class `SummarizedExperiment` whose colData and
#'   assay slots will be used to estimate the conditional distributions from
#'   experimental/biological properties into expression levels for each gene.
#' @param margins The @plan slot from an object of class `MarginalCollection`,
#'   defining the distributional families and link functions that relate
#'   `experiment`'s colData to the feature counts.
#' @param assay_name Which assay should we build the response data from?
#'   Defaults to the first assay in the `assayNames` slot of the experiment.
#' @return A list with the following components:
#' . xy: A data.frame whose rows are samples and columns include both the gene
#' .   expression counts (from all genes in the assay) and the covariates derived
#' .   from the `colData` and link functions.
#' . links: What are the formulas to use for each gene in the assay?
#' . features: What are the feature names across the assay?
#' . families: What are the distributional families to use for each gene in the.
# .   'assay?
#' @examples
#' exper <- dummy_data(20, 10, lambda = 10)
#' margins <- setup_margins(exper, ~cell_type)
#' prepare_data(exper, margins@plan)
#' @seealso [MarginalCollection]
prepare_data <- function(experiment, margins, assay_name = 1) {
  links <- field(margins$link, "links")
  features <- field(margins$feature, "gene_ids")
  families <- field(margins$family, "family")

  x <- t(as.matrix(assay(experiment, assay_name)))
  col_data <- string_to_factor(colData(experiment))

  combined_list <- list()
  for (j in seq_along(features)) {
    combined_list[[j]] <- list(
      formula = update_formula(links[[j]], features[[j]]),
      family = families[[j]],
      cbind(x[, features[j], drop = FALSE], col_data) |>
        data.frame(check.names = FALSE)
    )
  }

  combined_list
}

#' Estimate Gene-wise Distributional Regressions
#'
#' This function defines a template for looping over (a subset of) genes in a
#' SummarizedExperiment and estimating distributional regression models for
#' them. It is written in a functional style, so you can apply estimators beyond
#' the `gamboostLSS` and `gamlss` package estimators that are already available.
#'
#' @param estimator A function that will be used in the distributional
#'   regression for each feature. See `glmboost_estimator` or `gamlss_estimator`
#'   for example implementations.
#' @param y_names A vector of features for which to generate estimates. This can
#'   be used to re-estimate only a subset of features, for example.
#' @param experiment An object of class `SummarizedExperiment` whose colData and
#'   assay slots will be used to estimate the conditional distributions from
#'   experimental/biological properties into expression levels for each gene.
#' @param margins The @plan slot from an object of class `MarginalCollection`,
#'   defining the distributional families and link functions that relate
#'   `experiment`'s colData to the feature counts.
#' @param assay_name Which assay should we build the response data from?
#'   Defaults to the first assay in the `assayNames` slot of the experiment.
#' @param ncores An integer specifying the number of cores to use when
#'   estimating gene-wise regressions. Note that multithreading improvements
#'   depend on computer architecture. Defaults to 1 (no parallelization).
#' @return A list of fitted models whose class depends on the type of model
#'   defined by `estimator`. The i^th element of the list is the model for the
#'   i^th entry in `y_names`.
#' @importFrom SummarizedExperiment assay
#' @importFrom progress progress_bar
#' @importFrom pbapply pblapply
#' @importFrom parallel makeCluster clusterExport stopCluster
#' @seealso [glmboost_estimator], [gamlss_estimator]
#' @examples
#' exper <- dummy_data(20, 10, lambda = 10)
#' margins <- setup_margins(exper, ~cell_type)
#' model_estimates(glmboost_estimator(), rownames(exper), margins@plan, exper)
#' @export
model_estimates <- function(estimator, y_names, margins, experiment,
                            assay_name = 1, ncores = 1) {
  data <- prepare_data(experiment, margins, assay_name)

  if (ncores == 1) {
    pb <- progress_bar$new(
      total = length(data),
      format = "[:bar] :current/:total ETA: :eta"
    )

    estimates <- list()
    for (j in seq_along(data)) {
      estimates[[j]] <- do.call(estimator, data[[j]])
      pb$tick()
    }
  } else {
    cl <- makeCluster(ncores)
    clusterExport(cl, c("estimator"), envir=environment())
    estimates <- pblapply(data, \(u) do.call(estimator, u), cl = cl)
    stopCluster(cl)
  }

  estimates
}

#' Estimate Marginal Distributions from an Experiment
#'
#' @param .data An object of class `MarginalCollection` defining the
#'   distributional families and link functions to use when estimating each
#'   gene's marginal model.
#' @param template An object of class `SummarizedExperiment` whose colData and
#'   assay slots will be used to estimate the conditional distributions from
#'   experimental/biological properties into expression levels for each gene.
#' @param assay_name Which assay should we build the response data from?
#'   Defaults to the first assay in the `assayNames` slot of the experiment.
#' @param estimator A function that will be used in the distributional
#'   regression for each feature. See `glmboost_estimator` or `gamlss_estimator`
#'   for example implementations.
#' @param ... Other arguments to pass into the estimator object. For example,
#'   when using `glmboost_estimator` the argument `mstop` defines the number of
#'   iterations to use for each boosting model's fit.
#' @param ncores An integer specifying the number of cores to use when
#'   estimating gene-wise regressions. Note that multithreading improvements
#'   depend on computer architecture. Defaults to 1 (no parallelization).
#' @return A version of the `MarginalCollection` input to `.data` with the
#'   `@estimates` filled in with a list of regression models. The i^th component
#'   of the new `@estimates` corresponds to the i^th gene in the experiment.
#' @seealso [MarginalCollection]
#' @examples
#' exper <- dummy_data(20, 10, lambda = 10)
#' margins <- setup_margins(exper, ~cell_type)
#' estimate_marginals(margins, exper)
#' @importFrom vctrs field<-
#' @export
estimate_marginals <- function(.data, template, assay_name = 1, ncores = 1,
                               estimator = NULL, ...) {
  # gather preparatory data
  plan <- .data@plan
  refit <- field(plan$feature, "highlight")
  y_names <- field(plan$feature, "gene_ids")
  families <- field(plan$family, "family")
  if (is.null(estimator)) {
    estimator <- match_estimator(families)
  }

  # main estimation step
  estimates_ <- estimator(...) |>
    model_estimates(y_names[refit], plan[refit, ], template, assay_name, ncores)

  # populate the results
  estimates <- list()
  for (i in seq_along(y_names[refit])) {
    estimates[[y_names[refit][i]]] <- new(
      "Marginal",
      family = family_name(families[refit][[i]]),
      estimate = estimates_[[i]]$fit,
      pred_fun = estimates_[[i]]$pred_fun
    )
  }

  field(.data@plan$feature, "highlight") <- rep(FALSE, length(y_names))
  .data@estimates[y_names[refit]] <- estimates
  .data
}

#' Estimate a Joint Distribution
#'
#' This can be used for estimation once a joint distribution object has been
#' specified. After estimation, the `@margins@estimates` and `@dependence@fit`
#' slots will have been updated to include the fitted LSS and Copula regression
#' models.
#'
#' @param template A SummarizedExperiment object containing the assay and
#'   colData to use for marginal regression and multivariate copula modeling.
#' @param assay_name The name of the specific assay within the template data to
#'   use for estimation.
#' @param ncores An integer specifying the number of cores to use when
#'   estimating gene-wise regressions. Note that multithreading improvements
#'   depend on computer architecture. Defaults to 1 (no parallelization).
#' @param ... Other parameters to pass to to the marginal estimation function
#'   (e.g., number of iterations `mstop`) if using `glmboost_estimator()`.
#' @seealso [setup_simulator]
#' @export
estimate_simulator <- function(.data, template = NULL, assay_name = 1,
                               ncores = 1, ...) {
  if (is.null(template)) {
    template <- .data@template
  }

  .data@margins <- estimate(.data@margins, template, assay_name, ncores, ...)
  estimates <- .data@dependence@estimator(
    .data@margins,
    t(as.matrix(assay(template, assay_name))),
    colData(template)
  )
  .data@dependence@fit <- estimates$fit
  .data@dependence@sampler <- estimates$sampler

  .data
}

setGeneric("estimate", function(.data, ...) .data)

#' Method for `MarginalCollection` Estimation
#'
#' This is a method wrapper for `estimate_marginals`. It makes it possible to
#' use the same `estimate` method on both `MarginalCollection` and
#' `JointDistribution` objects.
#'
#' @seealso [estimate_simulator]
#' @export
setMethod("estimate", "MarginalCollection", estimate_marginals)

#' Method for `JointDistribution` Estimation
#'
#' This is a method wrapper for `estimate_simulator`. It makes it possible to
#' use the same `estimate` method on both `MarginalCollection` and
#' `JointDistribution` objects.
#'
#' @seealso [estimate_simulator]
#' @export
setMethod(
  "estimate",
  signature = "JointDistribution",
  definition = estimate_simulator
)

#' Extract the name of a Distributional Family
#'
#' This is a helper function to extract the family name attributes from gamlss
#' or gamboost distribution objects.
#'
#' @param family A gamlss.dist or gamboostLSS distribution object.
#' @return A string giving the name of the family.
#' @examples
#' x <- gamlss.dist::NO()
#' family.name(x)
family_name <- function(family) {
  if (class(family)[1] == "families") {
    return(attr(family, "name"))
  }
  head(family$family, 1)
}

#' Match an Estimator to a Family
#'
#' This is a helper to automatically detect whether to use the
#' `gamlss_estimator` or `glmboost_estimator` based on the distributional family
#' used in the `plan ` slot of the `MarginalCollection` defining a simulator.
#' For example, if we see `~GaussianLSS()`, then we know to use the
#' `glmboost_estimator`, because `GaussianLSS()` is a distribution in the
#' `gamboostLSS` package.
#' @param families A list containing distributional family objects in each
#'   component. Note that we will make the match using only the first component
#'   from this list.
#' @return A function giving the estimator that is most appropriate for the
#'   specified distribution.
#' @examples
#' x <- list(gamlss.dist::NO())
#' match_estimator(x)
#' y <- list(gamboostLSS::ZINBLSS())
#' match_estimator(y)
match_estimator <- function(families) {
  if ("gamlss.family" %in% class(families[[1]])) {
    estimator <- gamlss_estimator
  } else if ("families" %in% class(families[[1]])) {
    estimator <- glmboost_estimator
  } else {
    cli_abort("Could not match link function with either gamlss or gamboostLSS estimators. Have you provided a valid distribution?")
  }
  estimator
}
