#' Default Printing for a Marginal
#'
#' For a single marginal in a marginal collection, we just print the estimated
#' models.
#' @seealso [Marginal]
#' @export
setMethod("show", "Marginal", function(object) {
  print(object@estimate)
})

#' Default Printing for a MarginalCollection
#'
#' We use the vctrs package to support pretty printing of the plans and
#' estimates in a MarginalCollection. Our approach is based on this tutorial:
#' https://vctrs.r-lib.org/articles/pillar.html
#'
#' Features that have not yet been fitted will be highlighted in cyan, and
#' headers for main components of the simulator will be highlighted in purple.
#'
#' @seealso [MarginalCollection]
#' @importFrom stringr str_c str_flatten str_flatten_comma
#' @importFrom cli col_magenta col_cyan
#' @export
setMethod("show", "MarginalCollection", function(object) {
  n_print <- 3
  cat(col_magenta("Plan:\n"))

  print(head(object@plan, 2 * n_print))
  features <- field(object@plan$feature, "gene_ids")
  needs_fitting <- field(object@plan$feature, "highlight")
  if (any(needs_fitting)) {
    examples <- features[needs_fitting]
    if (length(examples) > n_print) {
      cat(glue("{col_cyan(str_flatten_comma(head(examples, n_print)))}, and {col_cyan(length(examples) - n_print)} {col_cyan('other features')} need fitting."))
    } else {
      cat(glue("{col_cyan(str_flatten(examples, collapse = ' and '))} need fitting."))
    }
  }

  cat(col_magenta("\nEstimates:\n"))
  print(head(map_dfr(object@estimates, ~ .@estimate, .id = "feature"), n_print))
  n_margins <- length(object@estimates)
  if (n_margins > n_print) {
    print(glue("... and {n_margins - n_print} additional features."))
  }
})

collapse_dim <- function(copulas) {
  n_features <- map_dbl(copulas, ~ .@dimension)
  sub(",\\s+([^,]+)$", " and \\1", toString(n_features))
}

#' Default Printing for a Joint
#'
#' For a single marginal in a marginal collection, we just print the estimated
#' models.
#' @seealso [Marginal]
#' @importFrom purrr map_dbl
#' @importFrom cli col_grey
#' @export
setMethod("show", "JointDistribution", function(object) {
  cat(col_grey("[Marginals]\n"))
  print(object@margins)

  if (!is.null(object@dependence)) {
    cat(col_grey("\n[Dependence]\n"))
    copulas <- object@dependence@fit
    plural <- ifelse(length(copulas) == 1, "", "s")
    print(glue("{length(copulas)} {class(copulas[[1]])}{plural} with {collapse_dim(copulas)} features"))
  }

  if (!is.null(object@template)) {
    cat(col_grey("\n[Template Data]\n"))
    print(object@template)
  }
})

#' Record Object for Families
#'
#' A separate class is helpful when we want to print the parameters associated
#' with a distribution, in addition to its name.
#'
#' @param family A specification of either the gamlss or gamboostLSS
#'   distributional family.
#' @return A record object of class distributional_family storing the name of
#'   the class attributes of gamlss.dist or gamboostLSS distribution.
#' @importFrom vctrs new_rcrd
#' @export
family_rcrd <- function(family) {
  new_rcrd(list(family = family), class = "distributional_family")
}

#' Record Object for Features
#'
#' For each feature, we want to store both the name and an attribute for whether
#' it should be highlighted.
#'
#' @param gene_ids A character vector to include in the final rcrd object.
#' @param highlight A boolean vector of the same length as `gene_ids`,
#'   specifying whether each gene should be highlighted.
#' @examples
#' tibble::tibble(id = gene_rcrd(LETTERS[1:5], rep(TRUE, 5)))
#' @export
gene_rcrd <- function(gene_ids, highlight = NULL) {
  if (is.null(highlight)) {
    highlight <- rep(FALSE, length(gene_ids))
  }
  new_rcrd(list(gene_ids = gene_ids, highlight = highlight), class = "gene_id")
}

#' Link Formula Features
#'
#' @param links A vector of formula objects to store in the rcrd object.
#' @export
#' @examples
#' tibble::tibble(id = link_rcrd(c(~ A + B, ~B, ~B)))
link_rcrd <- function(links) {
  new_rcrd(list(links = links), class = "link")
}

#' ptypes for gene_id
#'
#' This will ensure tibbles print <gene_id> at the top of every column
#' consisting of gene_id classes.
#' @importFrom vctrs vec_ptype_abbr
#' @examples
#' tibble::tibble(id = gene_rcrd(LETTERS[1:5], rep(TRUE, 5)))
#' @export
vec_ptype_abbr.gene_id <- function(x) {
  "gene_id"
}

#' ptypes for distributional_family
#'
#' This will ensure tibbles print <distn> at the top of every column consisting
#' of distributional families rcrd objects.
#' @importFrom vctrs vec_ptype_abbr
#' @export
vec_ptype_abbr.distributional_family <- function(x) {
  "distn"
}

#' ptypes for link
#'
#' This will ensure that tibbles print <link> at the top of every column
#' consisting of link rcrd objects.
#' @importFrom vctrs vec_ptype_abbr
#' @export
vec_ptype_abbr.link <- function(x) {
  "link"
}

#' Printing for Gene IDs
#'
#' This controls the printing of gene_id rcrd objects when they are included in
#' tibbles. We look up both the name and the highlight state of each feature,
#' and when printing, highlight those where the highlight is TRUE.
#' @importFrom cli col_cyan
#' @export
format.gene_id <- function(x, ...) {
  highlight <- field(x, "highlight")
  gene_ids <- field(x, "gene_ids")
  gene_ids[highlight] <- col_cyan(gene_ids[highlight])
  gene_ids
}

#' Printing for Distributional Families
#'
#' When we print a distributional family, we show both the name of the class and
#' the set of parameter names associated with it.
#' @importFrom glue glue
#' @importFrom vctrs field
#' @export
format.distributional_family <- function(x, ...) {
  result <- field(x, "family")
  for (i in seq_along(result)) {
    nm <- names(result[[i]])
    if (class(result[[i]])[1] == "families") {
      result[[i]] <- glue(
        "{attr(result[[i]], 'name')} [{str_flatten(nm, collapse=',')}]"
      )
    } else {
      cur_params <- names(which(unlist(result[[i]]$parameters)))
      result[[i]] <- glue(
        "{result[[i]]$family[1]} [{str_flatten(cur_params, collapse=',')}]"
      )
    }
  }
  result
}

#' Printing for Link
#'
#' To print link formulas in a readable way, we need to show the formula when it
#' is short (or general to all parameters) and split onto separate lines when we
#' need separate formulas across types.
#' @importFrom rlang is_formula
#' @importFrom purrr map2_chr
#' @export
format.link <- function(x, width = NULL, ...) {
  if (is.null(width)) {
    width <- options()$width
  }

  links <- field(x, "links")
  result <- vector(length = length(links))
  for (i in seq_along(result)) {
    if (is_formula(links[[i]])) {
      result[i] <- format(links[[i]])
    } else {
      result[i] <- map2_chr(
        links[[i]],
        names(links[[i]]),
        \(x, y) glue("{y}{format(x)}\n")
      ) |>
        str_flatten(collapse = ", ") |>
        str_trunc(floor(width / 3))
    }
  }

  result
}

#' Helper function for printing ANSI in Rmarkdown output
#' https://blog.djnavarro.net/posts/2021-04-18_pretty-little-clis/
#' @export
ansi_aware_handler <- function(x, options) {
  paste0(
    "<pre class=\"r-output\"><code>",
    fansi::sgr_to_html(x = x, warn = FALSE, term.cap = "256"),
    "</code></pre>"
  )
}
