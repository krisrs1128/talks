
test_that("Can reshape data with different assay name.", {
  exper <- dummy_data(10, 20, rpois, lambda = 10)
  pivot <- pivot_experiment(exper)
  expect_equal(nrow(pivot), 200)

  SummarizedExperiment::assayNames(exper) <- "gene_families"
  pivot <- pivot_experiment(exper)
  expect_equal(nrow(pivot), 200)
})