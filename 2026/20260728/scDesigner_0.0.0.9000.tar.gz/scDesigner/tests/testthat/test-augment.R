
colData <- SummarizedExperiment::colData

test_that("Augment PCA adds the correct number of dimensions to the colData.", {
  exper <- dummy_data(100, 20, rpois, lambda = 10)
  exper2 <- augment_pca(exper, 2)
  expect_equal(ncol(colData(exper)) + 2, ncol(colData(exper2)))
})

test_that("The new PC columns do agree with a naive calculation.", {
  exper <- dummy_data(100, 20, rpois, lambda = 10)
  exper2 <- augment_pca(exper, 2)

  naive_pc <- princomp(t(assay(exper)))$scores[, 1:2]
  colnames(naive_pc) <- c("PC1", "PC2")
  expect_equal(naive_pc, as.matrix(colData(exper2)[, c("PC1", "PC2")]))
})


test_that("Augment MDS adds the correct number of dimensions to the colData.", {
  exper <- dummy_data(100, 20, rpois, lambda = 10)
  exper2 <- augment_mds(exper, 2)
  expect_equal(ncol(colData(exper)) + 2, ncol(colData(exper2)))
})
