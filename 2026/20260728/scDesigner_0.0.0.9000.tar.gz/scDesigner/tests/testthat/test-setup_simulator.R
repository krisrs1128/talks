test_that("Spline pseudotime simulator can be setup with poisson data.", {
  exper <- dummy_data(10, 20, lambda = 10)
  simulator <- setup_simulator(
    exper,
    ~ ns(pseudotime, df = 3) * cell_type,
    ~ gamboostLSS::ZINBLSS()
  )

  expect_contains(class(simulator), "JointDistribution")
  expect_equal(nrow(simulator@margins@plan), nrow(exper))
  expect_null(simulator@margins@estimates)
  expect_equal(simulator@dependence, copula_gaussian(), ignore_attr = TRUE)
})

test_that("Spline pseudotime simulator can be setup with gaussian data.", {
  exper <- dummy_data(10, 20, rnorm, mean = 0, sd = 1)
  simulator <- setup_simulator(
    exper,
    ~ ns(pseudotime, df = 3) * cell_type,
    ~ gamboostLSS::GaussianLSS()
  )

  expect_contains(class(simulator), "JointDistribution")
  expect_equal(nrow(simulator@margins@plan), nrow(exper))
  expect_null(simulator@margins@estimates)
  expect_equal(simulator@dependence, copula_gaussian(), ignore_attr = TRUE)
})

test_that("Spline pseudotime simulator can be estimated with gaussian data.", {
  exper <- dummy_data(10, 20, rnorm, mean = 0, sd = 1)
  simulator <- simulator_wrapper(exper, family = ~ gamboostLSS::GaussianLSS())
  expect_contains(class(simulator), "JointDistribution")
  expect_equal(length(simulator@margins@estimates), nrow(exper))
})

test_that("Spline pseudotime simulator can be estimated with poisson data.", {
  exper <- dummy_data(10, 20, lambda = 10)
  simulator <- simulator_wrapper(exper, family = ~ gamboostLSS::NBinomialLSS())
  expect_contains(class(simulator), "JointDistribution")
  expect_equal(length(simulator@margins@estimates), nrow(exper))
})