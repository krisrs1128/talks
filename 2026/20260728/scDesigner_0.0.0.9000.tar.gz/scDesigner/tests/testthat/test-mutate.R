test_that("Can mutate to the identity matrix (single cov and list).", {
  exper <- dummy_data(10, 20, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_gaussian()
  )

  identity_matrix <- diag(nrow(exper))
  simulator2 <- simulator |>
    mutate_correlation(identity_matrix)

  expect_equal(length(simulator2@dependence@fit[[1]]), 1)
  new_corr <- copula::getSigma(simulator2@dependence@fit[[1]])
  expect_equal(identity_matrix, new_corr)
})

test_that("Mutated covariance throws error if wrong dimensions.", {
  exper <- dummy_data(10, 20, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_gaussian()
  )

  wrong_input <- diag(nrow(exper) / 2)
  expect_error({
    simulator |>
      mutate_correlation(wrong_input)
  })
})

test_that("Can mutate to block correlation matrix (single cov and list).", {
  exper <- dummy_data(10, 20, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_gaussian()
  )

  cors <- c(0.8, 0.6, 0.4)
  lengths <- c(8, 6, 6)
  blocks <- purrr::map2(cors, lengths, ~ matrix(rep(.x, .y^2), .y))
  rho <- as.matrix(Matrix::bdiag(blocks))
  diag(rho) <- 1

  simulator2 <- simulator |>
    mutate_correlation(rho)

  expect_equal(length(simulator2@dependence@fit[[1]]), 1)
  new_corr <- copula::getSigma(simulator2@dependence@fit[[1]])
  expect_equal(rho, new_corr)
})

test_that("Correctly handles named correlation lists.", {
  exper <- dummy_data(10, 20, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_gaussian(~cell_type)
  )

  correlations <- list(
    "cell_typeA" = diag(20),
    "cell_typeB" = matrix(0.3, 20, 20) + 0.7 * diag(20)
  )
  simulator2 <- simulator |>
    mutate_correlation(correlations)

  expect_equal(length(simulator@dependence@fit), 2)
  new_corrs <- map(simulator2@dependence@fit, ~ copula::getSigma(.))
  expect_equal(diag(20), new_corrs[["cell_typeA"]])
  expect_equal(correlations[["cell_typeB"]], new_corrs[["cell_typeB"]])

  # case of only one mutate
  correlations[["cell_typeB"]] <- NULL
  simulator2 <- simulator |>
    mutate_correlation(correlations)
  new_corrs <- map(simulator2@dependence@fit, ~ copula::getSigma(.))
  expect_equal(diag(20), new_corrs[["cell_typeA"]])
  expect_equal(
    copula::getSigma(simulator@dependence@fit[["cell_typeB"]]),
    new_corrs[["cell_typeB"]]
  )
})

test_that("Can generate high correlation samples.", {
  exper <- dummy_data(10, 20, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_gaussian()
  )

  # blocks with high and low covariance
  cors <- c(0.9, 0)
  lengths <- c(10, 10)
  blocks <- purrr::map2(cors, lengths, ~ matrix(rep(.x, .y^2), .y))
  rho <- as.matrix(Matrix::bdiag(blocks))
  diag(rho) <- 1

  simulator2 <- simulator |>
    mutate_correlation(rho)

  new_data <- expand_colData(
    exper,
    c("cell_type", "pseudotime"),
    resolution = 100
  )
  u <- simulator2@dependence@sampler(new_data)
  cor_u <- cor(u)
  diag(cor_u) <- NA
  expect_gte(mean(cor_u[1:10, 1:10], na.rm = TRUE), 0.85)
  expect_lte(mean(cor_u[11:20, 11:20], na.rm = TRUE), 0.05)
})
