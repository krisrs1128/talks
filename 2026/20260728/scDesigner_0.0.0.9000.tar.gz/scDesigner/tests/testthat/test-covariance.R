test_that("Low-dimensional covariances in two groups are learned.", {
  sigma1 <- diag(3)
  sigma2 <- matrix(c(1, 0, 0.4, 0, 1, 0.2, 0.4, 0.2, 1), ncol = 3)
  x <- rbind(
    mvtnorm::rmvnorm(500, sigma = sigma1),
    mvtnorm::rmvnorm(500, sigma = sigma2)
  )

  z <- data.frame(perm = sample(nrow(x))) |>
    mutate(group = ifelse(perm <= 500, "A", "B"))

  x <- x[z$perm, ]
  model <- covariance_model(x, z, ~group)
  expect_contains(class(model), "CovarianceModel")
  expect_lte(mean(abs(model@sigmas[["groupA"]] - sigma1)), 0.1)
  expect_lte(mean(abs(model@sigmas[["groupB"]] - sigma2)), 0.1)
})

test_that("Default covariance estimate uses the full dataset.", {
  sigma <- matrix(c(1, 0, 0.4, 0, 1, 0.2, 0.4, 0.2, 1), ncol = 3)
  x <- mvtnorm::rmvnorm(500, sigma = sigma)
  model <- covariance_model(x)
  expect_equal(length(model@sigmas), 1)
  expect_lte(mean(abs(model@sigmas[[1]] - sigma)), 0.1)
})
