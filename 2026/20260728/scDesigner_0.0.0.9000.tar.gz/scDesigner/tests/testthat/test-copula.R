test_that("Can estimate and sample from a Gaussian Copula.", {
  exper <- dummy_data(10, 20, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_gaussian()
  )

  copula_samples <- simulator@dependence@sampler(colData(exper))
  expect_equal(dim(copula_samples), rev(dim(exper)))
  expect_lte(max(copula_samples), 1)
  expect_gte(max(copula_samples), 0)
})

test_that("Can estimate and sample from a Gaussian Copula with two groups.", {
  exper <- dummy_data(10, 100, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_gaussian(~cell_type)
  )

  copula_samples <- simulator@dependence@sampler(colData(exper))
  expect_equal(dim(copula_samples), rev(dim(exper)))
  expect_lte(max(copula_samples), 1)
  expect_gte(max(copula_samples), 0)
})

build_sigma <- function() {
  sigma <- diag(20)
  sigma[1, 3] <- 0.9
  sigma[15, 10] <- 0.5
  sigma[2, 4] <- 0.1
  sigma[7, 19] <- 0.1
  sigma[10, 14] <- 0.7
  sigma[6, 8] <- 0.3
  sigma[3, 12] <- 0.5
  sigma <- .5 * (sigma + t(sigma))
  sv <- svd(sigma)
  sigma_sqrt <- ((sv$u) %*% diag(sqrt(sv$d)) %*% sv$v)
  list(sigma = sigma, sigma_sqrt = sigma_sqrt)
}

test_that("Can sample Gaussian copula with two very different covariances.", {
  assay <- SummarizedExperiment::assay
  `assay<-` <- SummarizedExperiment::`assay<-`

  exper <- dummy_data(5e3, 20, rnorm, mean = 0, sd = 1)
  sigma <- build_sigma()
  assay(exper)[, seq_len(ncol(exper) / 2)] <- sigma$sigma_sqrt %*% assay(exper)[, seq_len(ncol(exper) / 2)]

  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::GaussianLSS(),
    copula_def = copula_gaussian(~cell_type)
  )

  col_data <- colData(exper)
  samples <- qnorm(simulator@dependence@sampler(col_data))
  expect_lte(mean(abs(diag(20) - cov(samples[col_data$cell_type == "B", ]))), 0.1)
  expect_lte(mean(abs(sigma$sigma - cov(samples[col_data$cell_type == "A", ]))), 0.1)
})

test_that("Can estimate and sample from an Adaptive Thresholding Gaussian Copula.", {
  # test estimation
  exper <- dummy_data(10, 20, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_adaptive()
  )

  # test sampling
  copula_samples <- simulator@dependence@sampler(colData(exper))
  expect_equal(dim(copula_samples), rev(dim(exper)))
  expect_lte(max(copula_samples), 1)
  expect_gte(max(copula_samples), 0)

  Sigma <- copula::getSigma(simulator@dependence@fit[[1]])
  expect_gte(mean(Sigma == 0), 0.5)
})

test_that("Can estimate and sample from Vine Copula.", {
  # test estimation
  exper <- dummy_data(10, 20, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_vine()
  )
  expect_equal(class(simulator@dependence@fit[[1]]), c("vine", "vine_dist"))

  # test sampling
  copula_samples <- simulator@dependence@sampler(colData(exper))
  expect_equal(dim(copula_samples), rev(dim(exper)))
  expect_lte(max(copula_samples), 1)
  expect_gte(max(copula_samples), 0)
})

test_that("Can estimate and sample from a glasso-based Gaussian Copula.", {
  # test estimation
  exper <- dummy_data(10, 100, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_glasso(method = list(type = "confidence", param = 0.95))
  )

  # test sampling
  copula_samples <- simulator@dependence@sampler(colData(exper))
  expect_equal(dim(copula_samples), rev(dim(exper)))
  expect_lte(max(copula_samples), 1)
  expect_gte(max(copula_samples), 0)

  Sigma <- copula::getSigma(simulator@dependence@fit[[1]])
  expect_gte(mean(abs(solve(Sigma)) < 1e-6), 0.5)
})


test_that("Can estimate and sample from grouped version of Vine Copula.", {
  exper <- dummy_data(10, 20, rpois, lambda = 10)
  simulator <- simulator_wrapper(
    exper,
    family = ~ gamboostLSS::ZIPoLSS(),
    copula_def = copula_vine(~cell_type)
  )

  expect_equal(length(simulator@dependence@fit), 2)
  expect_equal(
    map(simulator@dependence@fit, class),
    list(
      "cell_typeA" = c("vine", "vine_dist"),
      "cell_typeB" = c("vine", "vine_dist")
    )
  )

  copula_samples <- simulator@dependence@sampler(colData(exper))
  expect_equal(dim(copula_samples), rev(dim(exper)))
  expect_lte(max(copula_samples), 1)
  expect_gte(max(copula_samples), 0)
})

test_that("Can extract parameters from copula types", {
  exper <- dummy_data(20, 10, lambda = 10)

  simulator <- setup_simulator(
    exper, ~pseudotime, ~ gamboostLSS::GaussianLSS(), copula_glasso()
  ) |>
    estimate()
  theta <- copula_parameters(simulator)
  expect_contains(class(theta), "matrix")

  simulator <- setup_simulator(
    exper, ~pseudotime, ~ gamboostLSS::GaussianLSS(), copula_vine()
  ) |>
    estimate()

  theta <- copula_parameters(simulator)
  expect_contains(class(theta), "rvine_list")
})
