test_that("Checking for dimensions in quantile sampling.", {
  exper <- dummy_data(100, 20, lambda = 10)
  margins <- setup_margins(
    exper,
    ~cell_type,
    ~ gamboostLSS::GaussianLSS()
  ) |>
    estimate(exper)

  # give an error if p and newdata don't have dimensions that agree
  col_data <- SummarizedExperiment::colData(exper) |>
    data.frame() |>
    dplyr::mutate(newdata_index = dplyr::row_number())
  expect_error(
    quantile_marginal(margins@estimates[[1]], col_data, c(0.2, 0.3))
  )

  # check when single quantile repeated
  quantiles <- quantile_marginal(margins@estimates[[1]], col_data, 0.5)
  expect_equal(nrow(quantiles), nrow(col_data))
  expect_lte(abs(mean(quantiles$value) - 10), 1)

  # check when multiple quantiles repeated
  quantiles <- quantile_marginal(
    margins@estimates[[1]],
    col_data,
    seq(0, 1, length.out = nrow(col_data))
  )
  expect_equal(nrow(quantiles), nrow(col_data))
})
