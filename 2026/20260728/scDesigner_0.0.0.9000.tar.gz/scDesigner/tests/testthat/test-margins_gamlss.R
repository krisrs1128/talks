test_that("gamboostLSS margins have the right dimension.", {
  exper <- dummy_data(100, 20, lambda = 10)
  margins <- setup_margins(exper, ~cell_type, ~gamlss.dist::NO())
  expect_equal(nrow(margins@plan), nrow(exper))

  for (family in list(~gamlss.dist::NBF(), ~gamlss.dist::PO(), ~gamlss.dist::ZANBI())) {
    margins <- setup_margins(exper, ~1, family)
    expect_equal(nrow(margins@plan), nrow(exper))
  }
})

test_that("Default links apply to all parameters.", {
  exper <- dummy_data(100, 20, lambda = 10)
  margins <- setup_margins(exper, ~cell_type, ~gamlss.dist::NO())
  link <- vctrs::field(margins@plan$link, "links")[[1]]
  expect_equal(link, ~cell_type)
})

test_that("Margins can have per-parameter formulas.", {
  exper <- dummy_data(100, 20, lambda = 10)
  margins <- setup_margins(exper, list(mu = ~cell_type, sigma = ~1), ~gamlss.dist::NO())
  link <- vctrs::field(margins@plan$link, "links")[[1]]
  expect_equal(names(link), c("mu", "sigma"))
  expect_equal(link[["mu"]], ~cell_type)
  expect_equal(link[["sigma"]], ~1)

  margins <- setup_margins(exper, list(mu = ~cell_type, sigma = ~1, nu = ~1), ~gamlss.dist::ZANBI())
  link <- vctrs::field(margins@plan$link, "links")[[1]]
  expect_equal(names(link), c("mu", "sigma", "nu"))
  expect_equal(link[["mu"]], ~cell_type)
  expect_equal(link[["sigma"]], ~1)
  expect_equal(link[["nu"]], ~1)
})

test_that("Can estimate LSS models on Poisson data using gamlss.", {
  exper <- dummy_data(100, 20, rpois, 10)
  for (family in list(~gamlss.dist::NO(), ~gamlss.dist::PO(), ~gamlss.dist::TF())) {
    for (formula in list(~cell_type, ~ pseudotime)) {
      fit <- setup_margins(exper, formula, family) |>
        estimate(exper)
     expect_equal(length(fit@estimates), nrow(exper))
      expect_contains(class(fit@estimates[[1]]@estimate$fit[[1]]), "gamlss")
      expect_equal(formula, vctrs::field(fit@plan$link, "links")[[1]])
    }
  }
})

test_that("Can estimate LSS models on NB data using gamlss.", {
  exper <- dummy_data(100, 20, rnbinom, 1, 0.1)
  for (family in list(~gamlss.dist::ZANBI(), ~gamlss.dist::NBF())) {
    for (formula in list(~cell_type, ~ pseudotime)) {
      fit <- setup_margins(exper, formula, family) |>
        estimate(exper) |>
        suppressWarnings()
      expect_equal(length(fit@estimates), nrow(exper))
      expect_contains(class(fit@estimates[[1]]@estimate$fit[[1]]), "gamlss")
      expect_equal(formula, vctrs::field(fit@plan$link, "links")[[1]])
    }
  }
})


test_that("Can sample marginals from gamlss continuous families.", {
  assayNames <- SummarizedExperiment::assayNames
  assay <- SummarizedExperiment::assay
  assays <- SummarizedExperiment::assays

  exper <- dummy_data(100, 20, rnorm, 10)
  for (family in list(~gamlss.dist::NO(), ~gamlss.dist::TF())) {
    for (formula in list(list(mu = ~cell_type, mu = ~ cell_type * pseudotime))) {
      fit <- setup_margins(exper, formula, family) |>
        estimate(exper)
      samples1 <- sample(fit)
      expect_equal(assayNames(samples1), "counts_1")
      expect_equal(dim(assay(samples1)), dim(exper))
      expect_lte(abs(mean(assay(samples1)) - mean(assay(exper))), 0.05)

      samples10 <- sample(fit, 10)
      expect_equal(assayNames(samples10), paste0("counts_", 1:10))
      expect_equal(dim(assay(samples10)), dim(exper))
      expect_lte(abs(mean(sapply(assays(samples10), mean)) - mean(assay(exper))), 0.1)
    }
  }
})

test_that("Can sample marginals from gamlss discrete families.", {
  assayNames <- SummarizedExperiment::assayNames
  assay <- SummarizedExperiment::assay

  exper <- dummy_data(100, 20, rnbinom, 1, 0.1)
  for (family in list(~gamlss.dist::PO(), ~gamlss.dist::ZANBI(), ~gamlss.dist::ZIP(), ~ gamlss.dist::NBF())) {
    for (formula in list(~cell_type, ~ cell_type * pseudotime)) {
      suppressWarnings({
        fit <- setup_margins(exper, formula, family) |>
          estimate(exper)
        samples1 <- sample(fit)
        expect_equal(assayNames(samples1), "counts_1")
        expect_equal(dim(assay(samples1)), dim(exper))

        samples10 <- sample(fit, 10)
        expect_equal(assayNames(samples10), paste0("counts_", 1:10))
        expect_equal(dim(assay(samples10)), dim(exper))
      })
    }
  }
})
